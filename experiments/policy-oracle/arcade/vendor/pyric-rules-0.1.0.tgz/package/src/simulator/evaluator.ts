/**
 * Firestore Security Rules Expression Evaluator.
 *
 * Walks the parsed AST and evaluates expressions against a simulated context.
 * Implements short-circuit evaluation for && and || to match Firestore behavior.
 *
 * Layers (built incrementally):
 *   1. Literals, identifiers, binary ops, comparisons
 *   2. Member access, bracket access, `in` operator
 *   3. Function calls, let bindings
 *   4. Method calls + MapDiff
 *   5. get()/exists() with mock resolution
 */
import type { Expression } from '../grammar/FirestoreAST.js';
import { MapDiff } from './mapdiff.js';
import { FirestoreSet } from './firestore-set.js';
import { mapLiteral } from './map-keys.js';
import { rulesValuesEqual } from './value-equality.js';
import { describeRulesType, isRulesMap } from './rules-type.js';
import { IndexAccessFailure, indexValue, readMember, sliceValue } from './index-access.js';
import { MembershipFailure, membership } from './membership.js';
import { RulesValue, NO_OP } from './wrappers/base.js';
import { Bytes } from './wrappers/bytes.js';
import { Path } from './wrappers/path.js';
import { Reference } from './wrappers/reference.js';
import { RulesFloat } from './wrappers/float.js';
import { Duration } from './wrappers/duration.js';
import { EvalError, ResourceLimitError } from './eval-error.js';
import {
  IntFailure,
  type IntOperator,
  intArithmetic,
  isOrderingOperator,
  isRulesInt,
  negateInt,
  numericLiteralValue,
  orderNumbers,
  rulesFloatValue,
  rulesInt,
} from './rules-int.js';
import { UnsupportedError } from './unsupported-error.js';

export { EvalError, EvalError as RuleEvalError } from './eval-error.js';
export { UnsupportedError } from './unsupported-error.js';

// ═══ Simulation Context ═══

export type { SimAuth, SimRequest, SimResource, SimulationContext } from './evaluation-context.js';
export type { ExprTraceEntry } from './trace-recorder.js';
export { TraceRecorder } from './trace-recorder.js';
import type { SimulationContext } from './evaluation-context.js';
import { evaluateFunctionCall, evaluateMethodCall } from './evaluation-builtins.js';
import { getOrBudgetSteps, type OrBudgetStep } from './list-proof-budget.js';

/** A pure expression has lexical bindings and accounting, with no database capabilities. */
type ExpressionContext = SimulationContext | Pick<SimulationContext, 'expressionBudget' | 'lookupBudget' | 'trace'>;

// ═══ Evaluator ═══

function evaluateBudgetOnly(expr: Expression, ctx: ExpressionContext, scope: Record<string, unknown>): void {
  const priorTrace = ctx.trace;
  ctx.trace = undefined;
  try {
    evaluate(expr, ctx, scope);
  } catch (e) {
    if (e instanceof ResourceLimitError) throw e;
  } finally {
    ctx.trace = priorTrace;
  }
}

function evaluateCore(expr: Expression, ctx: ExpressionContext, scope: Record<string, unknown>): unknown {
  if (!ctx.trace) return evaluateExpr(expr, ctx, scope);
  return ctx.trace.capture(expr, () => evaluateExpr(expr, ctx, scope));
}

function forkSimulationContext(ctx: ExpressionContext): ExpressionContext {
  return {
    ...ctx,
    lookupBudget: ctx.lookupBudget?.fork(),
    expressionBudget: ctx.expressionBudget?.fork(),
    trace: undefined,
  };
}

function runOrBudgetSteps(
  steps: readonly OrBudgetStep[],
  idx: number,
  expr: Expression,
  ctx: ExpressionContext,
  scope: Record<string, unknown>,
): unknown {
  if (idx >= steps.length) {
    return evaluateCore(expr, ctx, scope);
  }
  const step = steps[idx]!;
  if (step.kind === 'bind') {
    const boundVal = evaluateBinding(step.branch, ctx, scope);
    if (step.isLet) ctx.expressionBudget?.letBinding(step.operator);
    const nextScope: Record<string, unknown> = Object.assign(Object.create(null), scope);
    Object.defineProperty(nextScope, step.name, {
      value: boundVal,
      enumerable: true,
      writable: true,
      configurable: true,
    });
    return runOrBudgetSteps(steps, idx + 1, expr, ctx, nextScope);
  }
  if (step.kind === 'fork') {
    ctx.expressionBudget?.ternary(step.operator);
    if (step.condition) {
      evaluateBudgetOnly(step.condition, ctx, scope);
    }
    const lookupForks = [];
    const exprForks = [];
    for (let bIdx = 0; bIdx < step.branches.length; bIdx++) {
      const forkedCtx = forkSimulationContext(ctx);
      if (bIdx === 1) {
        forkedCtx.expressionBudget?.ternaryElse(step.operator);
      }
      evaluateBudgetOnly(step.branches[bIdx]!, forkedCtx, scope);
      if (forkedCtx.lookupBudget) lookupForks.push(forkedCtx.lookupBudget);
      if (forkedCtx.expressionBudget) exprForks.push(forkedCtx.expressionBudget);
    }
    ctx.lookupBudget?.mergeForks(lookupForks);
    ctx.expressionBudget?.mergeForks(exprForks);
    return runOrBudgetSteps(steps, idx + 1, expr, ctx, scope);
  }
  if (step.kind === 'variants') {
    const lookupForks = [];
    const exprForks = [];
    let sawFalse = false;
    let firstErr: unknown;
    for (const variantExpr of step.branches) {
      const forkedCtx = forkSimulationContext(ctx);
      try {
        const v = requireBoolean(evaluate(variantExpr, forkedCtx, scope), variantExpr);
        if (!v) sawFalse = true;
      } catch (e) {
        if (e instanceof ResourceLimitError || e instanceof UnsupportedError) throw e;
        if (firstErr === undefined) firstErr = e;
      }
      if (forkedCtx.lookupBudget) lookupForks.push(forkedCtx.lookupBudget);
      if (forkedCtx.expressionBudget) exprForks.push(forkedCtx.expressionBudget);
    }
    ctx.lookupBudget?.mergeForks(lookupForks);
    ctx.expressionBudget?.mergeForks(exprForks);
    if (sawFalse) return false;
    if (firstErr !== undefined) throw firstErr;
    return true;
  }
  if (step.side === 'before') {
    evaluateBudgetOnly(step.branch, ctx, scope);
    ctx.expressionBudget?.logicalRight(step.operator);
    let rv: unknown, rErr: unknown;
    try {
      rv = runOrBudgetSteps(steps, idx + 1, expr, ctx, scope);
    } catch (e) {
      rErr = e;
    }
    if (rErr instanceof ResourceLimitError) throw rErr;
    ctx.expressionBudget?.node(step.operator);
    if (rErr !== undefined) throw rErr;
    return rv;
  }
  let lv: unknown, lErr: unknown;
  try {
    lv = requireBoolean(runOrBudgetSteps(steps, idx + 1, expr, ctx, scope), expr);
  } catch (e) {
    lErr = e;
  }
  if (lErr instanceof ResourceLimitError) throw lErr;
  if (lErr === undefined && lv === true) {
    ctx.expressionBudget?.node(step.operator);
    return true;
  }
  ctx.expressionBudget?.logicalRight(step.operator);
  evaluateBudgetOnly(step.branch, ctx, scope);
  ctx.expressionBudget?.node(step.operator);
  if (lErr !== undefined) throw lErr;
  return false;
}

/**
 * Evaluate an expression against the simulation context. The public
 * entry point — recursive calls inside the evaluator come back through
 * here, so the optional trace wrapping naturally applies to every
 * sub-expression.
 */
export function evaluate(expr: Expression, ctx: ExpressionContext, scope: Record<string, unknown> = {}): unknown {
  if (ctx.expressionBudget || ctx.lookupBudget) {
    const steps = getOrBudgetSteps(expr);
    if (steps && steps.length > 0) {
      return runOrBudgetSteps(steps, 0, expr, ctx, scope);
    }
  }
  return evaluateCore(expr, ctx, scope);
}

function evaluateExpr(expr: Expression, ctx: ExpressionContext, scope: Record<string, unknown>): unknown {
  // One unit per evaluated node, charged inside the trace capture so the
  // node that reaches the limit records the limit as its error. A call by
  // name is charged as it is entered; every other node as it completes,
  // with a value or an error (`expression-budget.ts`).
  const budget = ctx.expressionBudget;
  if (!budget) return evaluateNode(expr, ctx, scope);
  if (expr.type === 'functionCall') {
    budget.call(expr);
    return evaluateNode(expr, ctx, scope);
  }
  let value: unknown;
  try {
    value = evaluateNode(expr, ctx, scope);
  } catch (e) {
    if (!(e instanceof ResourceLimitError)) budget.node(expr);
    throw e;
  }
  budget.node(expr);
  return value;
}

function evaluateNode(expr: Expression, ctx: ExpressionContext, scope: Record<string, unknown>): unknown {
  switch (expr.type) {
    // ═══ Layer 1: Literals, identifiers, binary ops ═══

    case 'literal':
      // RULES-B5: a source literal written with a decimal point is a FLOAT
      // (`1.0`, `1.5`), even when its value is integral. A literal of digits
      // is an int64, read from its source text so every bit survives
      // (`rules-int.ts`). Non-numeric literals (string/bool/null) pass through.
      if (typeof expr.value === 'number') return numericLiteralValue(expr.value, expr.raw);
      // A bytes literal (`b'...'`) evaluates to the same Bytes value as `toUtf8()`.
      if (expr.value instanceof Uint8Array) return new Bytes(expr.value);
      return expr.value;

    case 'identifier':
      return resolveIdentifier(expr.name, ctx, scope);

    case 'binaryOp':
      return evaluateBinaryOp(expr, ctx, scope);

    case 'unaryOp': {
      if (expr.op === '!') {
        return !requireBoolean(evaluate(expr.operand, ctx, scope), expr.operand);
      }
      if (expr.op === '-') {
        const v = evaluate(expr.operand, ctx, scope);
        // RULES-B5: negating a float stays a float (`-1.5 is float`); negating
        // an int stays an int, and `-MIN` is past int64, an error value.
        // Negating a duration is the duration of the opposite sign.
        const float = rulesFloatValue(v);
        if (float !== undefined) return new RulesFloat(-float);
        if (v instanceof Duration) return v.negated();
        const int = rulesInt(v);
        if (int !== undefined) return intResult(negateInt(int));
        throw new EvalError(
          `Unsupported operation error. Received: -${describeRulesType(v)}. Expected: -int, -float, -duration.`,
          expr,
        );
      }
      throw new EvalError(`Unknown unary op: ${expr.op}`, expr);
    }

    case 'ternary': {
      ctx.expressionBudget?.ternary(expr);
      const cond = requireBoolean(evaluate(expr.condition, ctx, scope), expr.condition);
      if (cond) return evaluate(expr.consequent, ctx, scope);
      ctx.expressionBudget?.ternaryElse(expr);
      return evaluate(expr.alternate, ctx, scope);
    }

    // ═══ Layer 2: Member access, bracket access, `in` ═══

    case 'memberAccess': {
      const obj = evaluate(expr.object, ctx, scope);
      // RULES-B2: field access on null/undefined is a runtime ERROR in
      // Firestore rules (CEL field selection has no overload for null),
      // not a silent null. Production denies the request. The common
      // guard `request.auth != null && request.auth.uid == ...` stays
      // safe because `&&` absorbs this error commutatively (RULES-B3) —
      // the `false` LHS uniquely determines the result.
      if (obj === null || obj === undefined) {
        throw new EvalError(
          `Property '${expr.property}' accessed on ${obj === null ? 'null' : 'undefined'} value`,
          expr,
        );
      }
      // Wrapper-owned property dispatch (Item 0.B hook 2). Wrappers like
      // Timestamp expose no readable properties — `t.year` returns null,
      // `t.year()` goes through callMethod. The base default returns null.
      // A path reads its bound names through `readMember` below, which
      // errors on an unbound name as production does.
      if (obj instanceof RulesValue && obj.typeName === 'reference') {
        const val = obj.field(expr.property);
        if (val !== null) return val;
      }
      // RULES-B2: reading a key that does not exist on a map is a runtime
      // ERROR in Firestore rules (`resource.data.typo` denies the request),
      // not the silent null this path used to return — that inversion made
      // `resource.data.typo == null` ALLOW where production DENYs. A key
      // present with an explicit null value still returns null (the key
      // exists). Guard with the `in` operator (`'f' in resource.data`) or
      // `resource.data.get('f', default)` to read a possibly-absent field.
      // Dot access on a list, string or other non-map is a type error, never
      // a JavaScript property (`index-access.ts`).
      if (!isRulesMap(obj)) {
        const member = readMember(obj, expr.property);
        if (member instanceof IndexAccessFailure) throw new EvalError(member.message, expr);
        return member;
      }
      if (Object.hasOwn(obj, expr.property)) return obj[expr.property];
      throw new EvalError(
        `No field '${expr.property}' on map (use 'in' or .get() to read a possibly-absent field)`,
        expr,
      );
    }

    case 'bracketAccess': {
      // Production evaluates the index before the value it indexes: a
      // request that reaches the expression limit inside `a[b]` stops in `b`
      // first (the limit-position capture in `captures.json`).
      const [idx, obj] = evaluateOperands([expr.index, expr.object], ctx, scope);
      // RULES-B2: index/key access on null/undefined errors in production
      // (no CEL index overload for null), absorbed by &&/|| where guarded.
      if (obj === null || obj === undefined) {
        throw new EvalError(`Index access on ${obj === null ? 'null' : 'undefined'} value`, expr);
      }
      // A key the map does not own is an error, as with dot access; a list,
      // string or path index must be an int within bounds; a path also reads
      // a bound name; other wrappers have no index operator
      // (`index-access.ts`, shared with the Storage evaluator). Guard a
      // possibly-absent key with `in` or read it with `map.get(key, default)`.
      const value = indexValue(obj, idx);
      if (value instanceof IndexAccessFailure) throw new EvalError(value.message, expr);
      return value;
    }

    case 'sliceAccess': {
      const [obj, start, end] = evaluateOperands([expr.object, expr.start, expr.end], ctx, scope);
      const sliced = sliceValue(obj, start, end);
      if (sliced instanceof IndexAccessFailure) throw new EvalError(sliced.message, expr);
      return sliced;
    }

    case 'inExpr': {
      // List and set elements under Rules value equality, own map keys only,
      // and production's errors for any other operand (`membership.ts`,
      // shared with the Storage evaluator). Production evaluates the
      // collection before the element: when both error, the collection's
      // error is the result.
      const [collection, element] = evaluateOperands([expr.collection, expr.element], ctx, scope);
      const result = membership(element, collection);
      if (result instanceof MembershipFailure) throw new EvalError(result.message, expr);
      return result;
    }

    case 'isExpr': {
      const value = evaluate(expr.value, ctx, scope);
      switch (expr.typeName) {
        case 'string': return typeof value === 'string';
        // RULES-B5: int and float are DISTINCT types. A bigint or a bare
        // safe-integer JS number is an int (`rules-int.ts`); a RulesFloat
        // wrapper, or a bare number at or above 2^53, is a float (#1781).
        // `number` matches either.
        // `1.5 is int` → false, `1 is float` → false, `1.0 is float` → true.
        case 'int':
          return isRulesInt(value);
        case 'float':
          return rulesFloatValue(value) !== undefined;
        case 'number':
          // Reject wrappers that coerce to NaN (LatLng/Path) — they're
          // not numbers even though valueOf() returns a Number. A RulesFloat
          // IS a number, so it must pass here.
          if (value instanceof RulesFloat) return true;
          if (value instanceof RulesValue) return false;
          return typeof value === 'number' || typeof value === 'bigint';
        case 'bool': return typeof value === 'boolean';
        case 'null': return value === null;
        case 'list': return Array.isArray(value);
        case 'set': return value instanceof FirestoreSet;
        case 'map':
          // Wrappers are objects but `is map` should be false for them —
          // a Timestamp is not a Map. Filter via instanceof RulesValue.
          if (value instanceof RulesValue) return false;
          // RULES-B12: MapDiff and FirestoreSet are internal types, not user
          // maps — `someDiff is map` / `someSet is map` must be false.
          if (value instanceof MapDiff || value instanceof FirestoreSet) return false;
          return typeof value === 'object' && value !== null && !Array.isArray(value);
        case 'path':
          // Production Firestore rules represent document reference fields as
          // `rules.Path` (`is path` -> true, `captures.json` "reference form is path").
          // Keep `is reference` matching via `default:` below for simulator compatibility.
          return (value instanceof RulesValue && value.typeName === 'path') || value instanceof Reference;
        default:
          // Wrapper type tags ('timestamp', 'duration', 'bytes', 'latlng',
          // 'reference') match via typeName. Item 0.B hook 5.
          if (value instanceof RulesValue) return value.typeName === expr.typeName;
          return false;
      }
    }

    case 'listLiteral':
      return evaluateOperands(expr.elements, ctx, scope);

    case 'mapLiteral': {
      const values = evaluateOperands(expr.entries.flatMap((entry) => [entry.key, entry.value]), ctx, scope);
      const entries: [string, unknown][] = [];
      for (let i = 0; i < values.length; i += 2) {
        const key = values[i];
        if (typeof key !== 'string') {
          throw new EvalError(`Type error. Received: [${describeRulesType(key)}] Expected: [string].`, expr);
        }
        entries.push([key, values[i + 1]]);
      }
      return mapLiteral(entries);
    }

    // ═══ Layer 3: Function calls ═══

    case 'functionCall':
      if (!('request' in ctx)) throw new EvalError('Function calls are outside the pure expression subset', expr);
      return evaluateFunctionCall(expr.name, expr.args, ctx, scope);

    // ═══ Layer 4: Method calls ═══

    case 'methodCall':
      if (!('request' in ctx)) throw new EvalError('Method calls are outside the pure expression subset', expr);
      return evaluateMethodCall(expr.object, expr.method, expr.args, ctx, scope);

    // ═══ Layer 5: Path literals ═══

    case 'pathLiteral': {
      // Resolve segments — string literals pass through, embedded
      // expressions (`$(uid)`) get evaluated and stringified.
      // Item 5.4: returns Path wrapper instead of raw string so `is path`
      // works. An embedded string is one segment, whatever it holds, so a
      // lookup reads a `/` inside it as naming no document (lookup-path.ts).
      // A match variable splices its segments instead: production binds
      // `{rest=**}` as a path, which pyric holds as a '/'-joined string.
      // Every embedded expression evaluates when an earlier one errors.
      const parts: string[] = [];
      let error: EvalError | undefined;
      for (const seg of expr.segments) {
        if (typeof seg === 'string') {
          ctx.expressionBudget?.pathSegment(expr);
          parts.push(seg);
        } else {
          try {
            const val = evaluate(seg, ctx, scope);
            if (val instanceof Path || val instanceof Reference) {
              parts.push(...val.segments);
              continue;
            }
            if (val instanceof RulesValue && val.typeName === 'path') {
              const segs = (val as { segments?: unknown }).segments;
              parts.push(
                ...(Array.isArray(segs)
                  ? (segs as string[])
                  : String(val).split('/').filter(Boolean)),
              );
              continue;
            }
            if (typeof val !== 'string' && !isRulesInt(val)) {
              throw new EvalError(`Type error. Received: [${describeRulesType(val)}] Expected: [string].`, seg);
            }
            if (isMatchVariable(seg, ctx, scope)) {
              parts.push(...String(val).split('/').filter(Boolean));
              continue;
            }
            parts.push(String(val));
          } catch (e) {
            error = firstError(error, e);
          }
        }
      }
      if (error) throw error;
      if (expr.isReference && parts.length >= 3 && parts[0] === 'databases' && parts[2] === 'documents') {
        return new Reference(parts.slice(3).join('/'), parts[1]);
      }
      return new Path(parts);
    }

    default:
      throw new EvalError(`Unknown expression type: ${(expr as Expression).type}`, expr);
  }
}

/**
 * Whether an embedded path expression is a bare match variable (`$(rest)`),
 * not shadowed by a `let` binding or function parameter. Its value is the
 * matched request segments joined by '/'; a request segment never holds a
 * '/', so splitting it gives back exactly the matched segments.
 */
function isMatchVariable(expr: Expression, ctx: ExpressionContext, scope: Record<string, unknown>): boolean {
  if (expr.type !== 'identifier') return false;
  return !Object.hasOwn(scope, expr.name) && 'pathVariables' in ctx && Object.hasOwn(ctx.pathVariables, expr.name);
}

// ═══ Identifier resolution ═══

export function resolveIdentifier(name: string, ctx: ExpressionContext, scope: Record<string, unknown>): unknown {
  // Local scope first (let bindings, function parameters). A binding whose
  // value errored holds that error, which decides only where it is read.
  if (Object.hasOwn(scope, name)) {
    const value = scope[name];
    if (value instanceof EvalError) throw value;
    return value;
  }

  if (!('pathVariables' in ctx)) throw new EvalError(`Undefined variable '${name}'`);

  // Path variables
  if (Object.hasOwn(ctx.pathVariables, name)) return ctx.pathVariables[name];

  // Built-in globals
  switch (name) {
    case 'request': return ctx.request;
    case 'resource':
      if (ctx.resource === null) throw new EvalError('Null value error.');
      return ctx.resource;
    case 'true': return true;
    case 'false': return false;
    case 'null': return null;
  }

  // RULES-B2: an unbound identifier (typo'd variable, undeclared name) is a
  // compile/runtime error in production rules, not a silent `undefined` that
  // later reads as null. Surface it as an EvalError so the handler DENYs and
  // &&/|| can absorb it where guarded.
  throw new EvalError(`Undefined variable '${name}'`);
}

/** True for the built-in top-level globals resolvable as values. Used to
 *  decide whether an unknown method-call target is a possible (unimplemented)
 *  namespace vs a real resolvable identifier. */
export function isKnownGlobal(name: string): boolean {
  return name === 'request' || name === 'resource'
    || name === 'true' || name === 'false' || name === 'null';
}

// ═══ Error values ═══

/**
 * True for an evaluation error production treats as a CEL error value: it
 * flows through operands and bindings and decides the verdict only where it
 * is used. A per-request resource limit ends the request at once, and a
 * simulator gap abstains at once, so neither is a value.
 */
export function isErrorValue(e: unknown): e is EvalError {
  return e instanceof EvalError && !(e instanceof ResourceLimitError) && !(e instanceof UnsupportedError);
}

/** `e` as an error value, rethrowing anything that is not one. */
function asErrorValue(e: unknown): EvalError {
  if (isErrorValue(e)) return e;
  throw e;
}

/**
 * The first of an operand list's errors once `e` is thrown: `first` when an
 * earlier operand errored, else `e`. A resource limit or simulator gap in `e`
 * is rethrown even after an earlier error.
 */
function firstError(first: EvalError | undefined, e: unknown): EvalError {
  const value = asErrorValue(e);
  return first ?? value;
}

/**
 * Evaluate every operand in order and return their values. Production goes on
 * evaluating the operands of a non-logical operator, a literal's elements,
 * and a call's receiver and arguments after one errors, and counts them
 * toward the expression limit; the result is then the first error.
 */
export function evaluateOperands(exprs: readonly Expression[], ctx: ExpressionContext, scope: Record<string, unknown>): unknown[] {
  const values = new Array<unknown>(exprs.length);
  let error: EvalError | undefined;
  for (let i = 0; i < exprs.length; i++) {
    try {
      values[i] = evaluate(exprs[i]!, ctx, scope);
    } catch (e) {
      error = firstError(error, e);
    }
  }
  if (error) throw error;
  return values;
}

/**
 * The value a function parameter or `let` binding holds: the evaluated value,
 * or the error value it evaluated to. Production binds the error and runs the
 * function body; reading the binding raises it (see `resolveIdentifier`).
 */
export function evaluateBinding(expr: Expression, ctx: ExpressionContext, scope: Record<string, unknown>): unknown {
  try {
    return evaluate(expr, ctx, scope);
  } catch (e) {
    return asErrorValue(e);
  }
}

// ═══ Binary operations with short-circuit ═══

function evaluateShortCircuitOp(
  operator: Expression,
  determiningValue: boolean,
  left: Expression,
  right: Expression,
  ctx: ExpressionContext,
  scope: Record<string, unknown>,
): unknown {
  let lv: unknown, lErr: unknown;
  try {
    lv = requireBoolean(evaluate(left, ctx, scope), left);
  } catch (e) {
    lErr = e;
  }
  if (lErr instanceof ResourceLimitError) throw lErr;
  if (lErr === undefined && lv === determiningValue) {
    ctx.trace?.skip(right);
    return determiningValue;
  }

  ctx.expressionBudget?.logicalRight(operator);
  let rv: unknown, rErr: unknown;
  try {
    rv = requireBoolean(evaluate(right, ctx, scope), right);
  } catch (e) {
    rErr = e;
  }
  if (rErr instanceof ResourceLimitError) throw rErr;
  if (rErr === undefined && rv === determiningValue) return determiningValue;
  if (lErr !== undefined) throw lErr;
  if (rErr !== undefined) throw rErr;
  return rv;
}

function evaluateBinaryOp(
  expr: Extract<Expression, { type: 'binaryOp' }>,
  ctx: ExpressionContext, scope: Record<string, unknown>,
): unknown {
  const { op, left, right } = expr;
  // RULES-B3: && and || are COMMUTATIVE error-absorbing operators in CEL,
  // not plain left-to-right short-circuit. Per the CEL spec: "if any of
  // their operands uniquely determines the result (false for &&, true for
  // ||) the other operand may or may not be evaluated, and if that
  // evaluation produces a runtime error, it will be ignored." So
  // `error && false` → false and `error || true` → true — the error is
  // absorbed by the determining operand regardless of position.
  //
  // We preserve laziness in the no-error path (the determining LHS skips
  // the RHS), and only evaluate the RHS to attempt absorption when the LHS
  // either errored or did not determine the result. If neither operand
  // determines the result and one errored, the error propagates (re-thrown)
  // so the handler DENYs.
  if (op === '&&') return evaluateShortCircuitOp(expr, false, left, right, ctx, scope);
  if (op === '||') return evaluateShortCircuitOp(expr, true, left, right, ctx, scope);

  // Both operands evaluate, and count, when the left one errors; the left
  // error is the result.
  let lv: unknown, rv: unknown, error: EvalError | undefined;
  try {
    lv = evaluate(left, ctx, scope);
  } catch (e) {
    error = asErrorValue(e);
  }
  try {
    rv = evaluate(right, ctx, scope);
  } catch (e) {
    error = firstError(error, e);
  }
  if (error) throw error;

  // Wrapper-aware binary op dispatch (Item 0.B hook 4). Cross-type
  // arithmetic like `Timestamp + Duration → Timestamp` and lexicographic
  // `Bytes < Bytes` are handled here via the wrapper's own `binaryOp`
  // method. NO_OP means the wrapper doesn't claim this op — fall through
  // to the generic numeric switch below.
  //
  // == and != intentionally bypass this hook — they route through
  // rulesValuesEqual above, which already calls the wrapper's
  // `equals()`. Splitting "value equality" from "operator dispatch"
  // keeps each wrapper's contract clean.
  // Two numbers order through `orderNumbers` (`rules-int.ts`), shared with
  // Storage: two ints exactly, an int and a float as doubles.
  if (isOrderingOperator(op)) {
    const ordered = orderNumbers(op, lv, rv);
    if (ordered !== undefined) return ordered;
  }
  if (op !== '==' && op !== '!=') {
    if (lv instanceof RulesValue) {
      const r = lv.binaryOp(op, rv);
      if (r !== NO_OP) return r;
    }
    // RULES-B5: `int OP float` (bare-number LHS, RulesFloat RHS) must yield a
    // float and preserve operand ORDER (unlike Duration/Timestamp this is a
    // genuinely ordered numeric op for `-`/`/`/`%` and the comparisons). Route
    // it through `RulesFloat(lv).binaryOp(op, rv)` so the result re-tags as a
    // float and `5 / 2.0` does float division (2.5), not int truncation.
    if (isNumeric(lv) && rv instanceof RulesFloat) {
      const r = new RulesFloat(Number(lv)).binaryOp(op, rv);
      if (r !== NO_OP) return r;
    }
    // Right-side dispatch for symmetric/commutative ops only. Avoids
    // surprises like `1 - duration` accidentally reversing semantics.
    if (rv instanceof RulesValue && (op === '+' || op === '*')) {
      const r = rv.binaryOp(op, lv);
      if (r !== NO_OP) return r;
    }
    // Risk 2 (REBUILD_PLAN Item 1.2): if either operand is still a
    // RulesValue at this point, the only remaining path is generic
    // numeric coercion via valueOf(). For LatLng that yields NaN
    // (silent DENY); for Duration/Timestamp/Bytes it would silently
    // drop the type. Both are real type errors in the rule (e.g.
    // `latlng + 1`, `duration > 60`), not sim gaps — surface as
    // EvalError so handler.ts maps to DENY-with-error instead of a
    // misleading "passed but came out false" or "UNSUPPORTED". A string
    // operand is no exception: production has no string + timestamp,
    // string + duration, or string + bytes overload.
    if (lv instanceof RulesValue || rv instanceof RulesValue) {
      throw new EvalError(
        `Operator '${op}' is not defined between ${describeRulesType(lv)} and ${describeRulesType(rv)}`,
      );
    }
  }

  // RULES-B12: ordered comparisons (`< > <= >=`) require both operands to be the
  // SAME comparable type. CEL has no cross-type ordering overload, so `'a' < 1`
  // is an error, not the JS-coerced `false` the bare `as number` casts produced.
  // (Comparable wrappers — Bytes, Timestamp, Duration — were already dispatched
  // via binaryOp above, and two numbers through `orderNumbers`; a pair of
  // strings is the one ordered pair that reaches the switch below.)
  if (op === '<' || op === '>' || op === '<=' || op === '>=') {
    const sameComparable =
      (isNumeric(lv) && isNumeric(rv)) ||
      (typeof lv === 'string' && typeof rv === 'string');
    if (!sameComparable) {
      throw new EvalError(
        `Operator '${op}' is not defined between ${typeof lv} and ${typeof rv}`,
      );
    }
  }

  switch (op) {
    case '==': return rulesValuesEqual(lv, rv);
    case '!=': return !rulesValuesEqual(lv, rv);
    case '<': return (lv as number) < (rv as number);
    case '>': return (lv as number) > (rv as number);
    case '<=': return (lv as number) <= (rv as number);
    case '>=': return (lv as number) >= (rv as number);
    case '+': {
      // Production's `+` accepts int + int, float + float, string + string,
      // duration + duration, duration + timestamp, and timestamp + duration.
      // Every other pair is "Unsupported operation error", an error value
      // that `&&` and `||` absorb: `'a' + 1` errors rather than coercing,
      // `[1] + [2]` errors rather than concatenating (`list.concat(list)`
      // joins lists), and `'at ' + request.time`, `bytes + bytes`, and
      // `duration + 1` error rather than joining. The float and the
      // duration and timestamp pairs were dispatched above through the
      // wrappers' `binaryOp`, and any other wrapper operand errored there.
      if (typeof lv === 'string' && typeof rv === 'string') return lv + rv;
      if (isNumeric(lv) && isNumeric(rv)) return numericArithmetic('+', lv, rv);
      throw new EvalError(
        `Operator '+' is not defined between ${describeRulesType(lv)} and ${describeRulesType(rv)}`,
      );
    }
    case '-':
    case '*':
    case '/':
    case '%': {
      if (!isNumeric(lv) || !isNumeric(rv)) {
        throw new EvalError(
          `Unsupported operation error. Received: ${describeRulesType(lv)} ${op} ${describeRulesType(rv)}.`,
        );
      }
      return numericArithmetic(op, lv, rv);
    }
    default: throw new EvalError(`Unknown binary op: ${op}`);
  }
}

/** An int (a bigint or a bare integral number) or a bare number with a fraction from a host value. */
function isNumeric(value: unknown): value is bigint | number {
  return typeof value === 'bigint' || typeof value === 'number';
}

/**
 * Arithmetic on two numbers that are not `RulesFloat` wrappers (those
 * dispatched above). Two ints compute in int64 (`rules-int.ts`): a result
 * past the range, or a zero divisor, is an error value. A bare number with a
 * fraction, from a host value, makes the result a float.
 */
function numericArithmetic(op: IntOperator, lv: bigint | number, rv: bigint | number): unknown {
  const l = rulesInt(lv);
  const r = rulesInt(rv);
  if (l !== undefined && r !== undefined) return intResult(intArithmetic(op, l, r));
  return new RulesFloat(Number(lv)).binaryOp(op, rv);
}

/** An int result, or its failure as an error value. */
function intResult(result: bigint | IntFailure): bigint {
  if (result instanceof IntFailure) throw new EvalError(result.message);
  return result;
}

/** An `&&`/`||`/`!` operand, a ternary condition, or an allow condition must be a bool. */
export function requireBoolean(value: unknown, expr: Expression): boolean {
  if (typeof value === 'boolean') return value;
  throw new EvalError(`Type error. Received: [${describeRulesType(value)}] Expected: [bool].`, expr);
}
