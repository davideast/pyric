/**
 * `firestoreRules(source)` — the deep, safe-by-default handle on a Firestore
 * ruleset.
 *
 * The constructor compiles once. If the source does not parse, or breaks one
 * of production's compile limits (call depth, `let` count, nesting), it throws
 * {@link RulesCompileError} (with `.issues`); past that point the handle is
 * known-good and its verbs never throw on rule outcomes. `simulate` returns
 * a summary whether cases pass, fail, or hit an unimplemented feature;
 * `lint` returns findings; `explain` returns a structured account of a
 * single case; `toJSON` returns the parsed rules as plain data.
 */

import type { FirestoreRules, ImportDecl } from '../grammar/FirestoreAST.js';
import { parseToASTOrError } from '../grammar/FirestoreParser.js';
import { describeCompileLimitViolations } from '../grammar/compile-limits.js';
import { isFirestoreServiceName } from '../grammar/service-blocks.js';
import {
  checkRulesSource,
  DUPLICATE_SERVICE_REASON,
  duplicateServiceRejection,
  sourceSizeViolation,
  type RulesSourceRejection,
} from '../grammar/source-compile-limits.js';
import { SimulateFirestoreRulesHandler } from '../simulator/handler.js';
import {
  AUTHORED_ROOT_SOURCE_FILE,
  findModuleErrorImportLine,
  isLocalRelativeModuleSpecifier,
  readAuthoredSourceMap,
  resolveModulesBrowser,
  type AuthoredSourceMap,
} from '../modules/resolver-browser.js';
import { projectEvaluatedRule } from '../test/spec.js';
import type { TestCase, TestResult } from '../test/spec.js';
import { RulesCompileError } from './errors.js';
import type { RuleIssue } from './issue.js';
import {
  compileLimitViolationToIssue,
  parseErrorToIssue,
} from './issue.js';
import { lintSource } from './lint.js';
import type {
  FirestoreCase,
  CaseResult,
  Explanation,
  SimulationSummary,
} from './case-types.js';

export interface FirestoreRuleset {
  /** Structural, security, and budget findings on the compiled ruleset.
   *  No parse errors — the source already compiled. */
  lint(): RuleIssue[];
  /** Run every case. Never throws on a rule outcome: a denied or abstained
   *  case is reported in the returned summary. */
  simulate(cases: FirestoreCase[]): SimulationSummary;
  /** The structured account of why one case resolved as it did. */
  explain(oneCase: FirestoreCase): Explanation;
  /** The parsed ruleset as plain data (the AST). */
  toJSON(): FirestoreRules;
}

function resultToCaseResult(fc: FirestoreCase, r: TestResult): CaseResult {
  return {
    case: fc,
    description: r.description,
    expectation: r.expectation,
    decision: r.decision,
    passed: r.state === 'PASSED',
    unsupported: r.state === 'UNSUPPORTED',
    trace: r.trace,
    notes: r.notes,
    ...(r.pathResolution ? { pathResolution: r.pathResolution } : {}),
    evaluatedExpressions: r.evaluatedExpressions ?? 0,
    ...(r.resourceLimit ? { resourceLimit: r.resourceLimit } : {}),
    ...(r.queryProof ? { queryProof: r.queryProof } : {}),
  };
}

/** A degenerate result for a case the engine could not even run (e.g. the
 *  compiled source went empty). Reported as failed rather than thrown. */
function unrunnableResult(fc: FirestoreCase, message: string): CaseResult {
  return {
    case: fc,
    description: fc.description,
    expectation: fc.expectation,
    decision: 'DENY',
    passed: false,
    unsupported: false,
    trace: [],
    notes: [message],
    evaluatedExpressions: 0,
  };
}

function cloneAstValue<T>(value: T): T {
  if (value === null || typeof value !== 'object') return value;
  if (value instanceof Uint8Array) return new Uint8Array(value) as T;
  if (Array.isArray(value)) {
    return value.map((item) => cloneAstValue(item)) as T;
  }
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) return value;
  const copy: Record<string, unknown> = proto === null ? Object.create(null) : {};
  for (const [key, child] of Object.entries(value as Record<string, unknown>)) {
    Object.defineProperty(copy, key, {
      value: cloneAstValue(child),
      enumerable: true,
      writable: true,
      configurable: true,
    });
  }
  return copy as T;
}

class FirestoreRulesetImpl implements FirestoreRuleset {
  private readonly handler = new SimulateFirestoreRulesHandler();
  private readonly sourceMap: AuthoredSourceMap;
  constructor(
    private readonly rawSource: string,
    private readonly source: string,
    private readonly ast: FirestoreRules,
    private readonly authoredImports?: readonly ImportDecl[],
  ) {
    this.sourceMap = readAuthoredSourceMap(source);
  }

  lint(): RuleIssue[] {
    return lintSource(this.rawSource, 'cloud.firestore').filter(
      (issue) => issue.origin !== 'parse',
    );
  }

  simulate(cases: FirestoreCase[]): SimulationSummary {
    // The cases are a caller's: intake checks each one's shape and refuses,
    // as UNSUPPORTED with the reason, one either engine would read as a
    // different request.
    const result = this.handler.simulateParsed(this.ast, this.source, cases as TestCase[], {
      sourceMap: this.sourceMap,
      authoredImports: this.authoredImports,
      publicCases: true,
    });
    if (!result.success) {
      // The source compiled in the constructor and the parsed AST is
      // evaluated directly, so a failure here is not expected. The front
      // door must not throw. Report every case
      // as failed with the engine's message.
      const message = result.error.message;
      const caseResults = cases.map((c) => unrunnableResult(c, message));
      return {
        passed: 0,
        failed: caseResults.length,
        unsupported: 0,
        cases: caseResults,
      };
    }
    const caseResults = result.data.results.map((r, i) =>
      resultToCaseResult(cases[i], r),
    );
    return {
      passed: result.data.passed,
      failed: result.data.failed,
      unsupported: result.data.unsupported,
      cases: caseResults,
    };
  }

  explain(oneCase: FirestoreCase): Explanation {
    const summary = this.simulate([oneCase]);
    const r = summary.cases[0];
    const deciding = toEngineResult(r);
    const explanation: Explanation = {
      decision: r.decision,
      expectation: r.expectation,
      passed: r.passed,
      unsupported: r.unsupported,
      trace: r.trace,
      notes: r.notes,
      evaluatedExpressions: r.evaluatedExpressions,
    };
    if (r.resourceLimit) explanation.resourceLimit = r.resourceLimit;
    if (deciding) explanation.deciding = deciding;
    if (r.pathResolution) explanation.pathResolution = r.pathResolution;
    if (r.queryProof) explanation.queryProof = r.queryProof;
    return explanation;
  }

  toJSON(): FirestoreRules {
    return cloneAstValue(this.ast);
  }
}

/** Reconstruct the minimal `TestResult` shape `projectEvaluatedRule` needs
 *  from a `CaseResult`, so the deciding-rule projection stays a single
 *  implementation shared with the engine. */
function toEngineResult(r: CaseResult) {
  return projectEvaluatedRule({
    description: r.description,
    expectation: r.expectation,
    state: r.passed ? 'PASSED' : r.unsupported ? 'UNSUPPORTED' : 'FAILED',
    decision: r.decision,
    trace: r.trace,
    notes: r.notes,
    ...(r.pathResolution ? { pathResolution: r.pathResolution } : {}),
    ...(r.resourceLimit ? { resourceLimit: r.resourceLimit } : {}),
  });
}

/**
 * Compile Firestore rules source into a deep, safe-by-default handle.
 *
 * @throws {RulesCompileError} when the source does not parse, declares one
 *   service twice, or breaks one of production's compile limits. The thrown
 *   error carries the compile-blocking issues on `.issues`.
 */
function remapRejectionToAuthoredSource(
  rejection: RulesSourceRejection,
  effectiveSource: string,
  authoredImports: readonly ImportDecl[] | undefined,
): RulesSourceRejection {
  const sourceMap = readAuthoredSourceMap(effectiveSource);
  if (sourceMap.size === 0) return rejection;
  const mapLine = (line: number | undefined): number | undefined => {
    if (line === undefined) return undefined;
    const entry = sourceMap.get(line);
    if (entry === undefined) return line;
    if (entry.authoredFile === AUTHORED_ROOT_SOURCE_FILE) return entry.authoredLine;
    return findModuleErrorImportLine(authoredImports, `'${entry.authoredFile}'`, 1);
  };
  if (rejection.kind === 'parse') {
    const mappedLine = mapLine(rejection.line) ?? rejection.line;
    return { ...rejection, line: mappedLine };
  }
  const violations = rejection.violations.map((v) => {
    const mappedLine = mapLine(v.line);
    return mappedLine === undefined ? v : { ...v, line: mappedLine };
  });
  return {
    kind: 'compile',
    violations,
    message: `rules did not compile: ${describeCompileLimitViolations(violations)}`,
  };
}

export function firestoreRules(source: string): FirestoreRuleset {
  let effectiveSource = source;
  let authoredImports: readonly ImportDecl[] | undefined;
  if (sourceSizeViolation(source) === null) {
    const initial = parseToASTOrError(source);
    if (
      initial.ok &&
      initial.ast.version === '2+modules' &&
      (initial.ast.service === undefined || isFirestoreServiceName(initial.ast.service.name)) &&
      duplicateServiceRejection(initial.ast) === null &&
      !initial.ast.imports?.some((imp) => isLocalRelativeModuleSpecifier(imp.module))
    ) {
      authoredImports = initial.ast.imports;
      const resolved = resolveModulesBrowser(source, {
        targetService: 'cloud.firestore',
        sourceFile: AUTHORED_ROOT_SOURCE_FILE,
      });
      if (!resolved.success) {
        const line = findModuleErrorImportLine(
          initial.ast.imports,
          resolved.error.message,
          initial.ast.loc?.line ?? 1,
        );
        const issue: RuleIssue = {
          code: resolved.error.code,
          severity: 'error',
          message: resolved.error.message,
          line,
          origin: 'parse',
        };
        throw new RulesCompileError(
          `Firestore rules module resolution failed (${resolved.error.code}): ${resolved.error.message}`,
          [issue],
        );
      }
      effectiveSource = resolved.data.resolved;
    }
  }
  const checked = checkRulesSource(effectiveSource);
  if (!checked.ok) {
    const rejection =
      effectiveSource !== source
        ? remapRejectionToAuthoredSource(checked.rejection, effectiveSource, authoredImports)
        : checked.rejection;
    throw compileError(effectiveSource, rejection);
  }
  return new FirestoreRulesetImpl(source, effectiveSource, checked.ast, authoredImports);
}

/**
 * The error `firestoreRules()` throws for a source production's load check
 * refuses: it does not parse, it declares one service twice, or it is past one
 * of production's compile limits (call depth, `let` count, nesting).
 */
function compileError(source: string, rejection: RulesSourceRejection): RulesCompileError {
  if (rejection.kind === 'compile') {
    return new RulesCompileError(
      `Firestore rules source failed to compile: ${describeCompileLimitViolations(rejection.violations)}`,
      rejection.violations.map(compileLimitViolationToIssue),
    );
  }
  const parsed = parseToASTOrError(source);
  if (!parsed.ok) {
    return new RulesCompileError('Firestore rules source failed to compile', [parseErrorToIssue(parsed.error)]);
  }
  // The source parses, so the check refused its service blocks: two of them
  // name one service (capture c5b-two-firestore-services).
  const declaresServiceTwice = duplicateServiceRejection(parsed.ast) !== null;
  if (declaresServiceTwice) return serviceError(DUPLICATE_SERVICE_REASON, rejection.line);
  return new RulesCompileError('Firestore rules source failed to compile', []);
}

/** A refusal of the source's service blocks with production's reason, at the refused block's `service` keyword. */
function serviceError(reason: string, line: number): RulesCompileError {
  const issue: RuleIssue = { code: 'PARSE_ERROR', severity: 'error', message: reason, line, origin: 'parse' };
  return new RulesCompileError(`Firestore rules source failed to compile: ${reason}`, [issue]);
}
