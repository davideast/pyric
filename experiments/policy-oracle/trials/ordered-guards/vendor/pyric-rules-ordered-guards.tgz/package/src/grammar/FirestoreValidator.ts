import type {
  FirestoreRules, MatchBlock, FunctionDef, Operation, PathSegment, ServiceBlock,
} from './FirestoreAST.js';
import { countDocumentAccessCalls } from './document-access-count.js';
import { compileLimitViolations } from './compile-limits.js';
import { recursiveScope, resolveDocumentSegments } from './recursive-scope.js';
import {
  isStorageServiceName,
  selectServicesToAnalyze,
  topLevelMatches,
  withSingleService,
} from './service-blocks.js';
import {
  collectRulesetScopes, exprDepth,
  functionReferences, ruleReferences,
  type NameReferences, type RulesetScopes,
} from './function-scopes.js';
import { resolveBundledModulesForAnalysis } from '../modules/resolver-browser.js';
import {
  foldConstants,
  guardsAuthTransitive,
  referencesRequestDataAnyTransitive,
  referencesResourceDataAnyTransitive,
  validatesRequestDataTransitive,
} from './validator-predicates.js';

export interface ValidationFinding {
  code: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  path: string;
  operation?: string;
  message: string;
}

const WRITE_OPS: Set<Operation> = new Set(['write', 'create', 'update', 'delete']);
const READ_OPS: Set<Operation> = new Set(['read', 'get', 'list']);
const DATA_WRITE_OPS: Set<Operation> = new Set(['write', 'create', 'update']);

export interface ValidateRulesOptions {
  targetService?: 'cloud.firestore' | 'firebase.storage' | 'all';
  rawSource?: string;
}

export function validateFirestoreRules(
  inputAst: FirestoreRules,
  options?: ValidateRulesOptions,
): ValidationFinding[] {
  const selectedServices = selectServicesToAnalyze(inputAst, options?.targetService);

  if (selectedServices.length === 0) return [];

  const preparedByService = new Map<
    ServiceBlock,
    { ast: FirestoreRules; scopes: RulesetScopes; globalFns: Set<FunctionDef> }
  >();
  const prepareService = (service: ServiceBlock) => {
    const cached = preparedByService.get(service);
    if (cached !== undefined) return cached;
    let svcTarget: 'cloud.firestore' | 'firebase.storage' = 'cloud.firestore';
    if (isStorageServiceName(service.name)) {
      svcTarget = 'firebase.storage';
    }
    const ast = resolveBundledModulesForAnalysis(
      withSingleService(inputAst, service),
      options?.rawSource,
      { targetService: svcTarget },
    );
    const entry = {
      ast,
      scopes: collectRulesetScopes(ast),
      globalFns: new Set(ast.functions ?? []),
    };
    preparedByService.set(service, entry);
    return entry;
  };

  const prepared = selectedServices.map(prepareService);

  // Track global functions called across any recognized service block so multi-service
  // files do not falsely report QUA-4 on a global helper used only by a sibling service.
  const calledGlobalFnNames = new Set<string>();
  const recognizedServices = selectServicesToAnalyze(inputAst, 'all');
  if (recognizedServices.length > 1) {
    const allPrepared = recognizedServices.map(prepareService);
    for (const { scopes, globalFns } of allPrepared) {
      for (const scoped of scopes.rules) {
        for (const callee of ruleReferences(scoped).callees) {
          if (globalFns.has(callee)) calledGlobalFnNames.add(callee.name);
        }
      }
      for (const scoped of scopes.functions) {
        for (const callee of functionReferences(scoped).callees) {
          if (globalFns.has(callee)) calledGlobalFnNames.add(callee.name);
        }
      }
    }
  }

  const findings: ValidationFinding[] = [];
  for (let serviceIndex = 0; serviceIndex < prepared.length; serviceIndex++) {
    const entry = prepared[serviceIndex];
    if (entry === undefined) continue;
    const { ast, scopes } = entry;
    const isSecondaryService = serviceIndex > 0;
    const rootMatches = topLevelMatches(ast.service);
    const isStorage = isStorageServiceName(ast.service?.name);
    const outerScope = [...(ast.functions ?? []), ...(ast.service.functions ?? [])];
    const fnScopes = new Map<FunctionDef, ReadonlyMap<string, FunctionDef>>(
      scopes.functions.map((s) => [s.fn, s.functions]),
    );

    // SEC-4: Check for default deny
    checkDefaultDeny(rootMatches, findings, outerScope, fnScopes);

    // QUA-3: Duplicate function names in one scope
    checkDuplicateFunctions(ast, findings, isSecondaryService);

    // SEM-4, SEM-5, QUA-4: names resolved by declaration scope
    checkNameResolution(scopes, findings, isSecondaryService, calledGlobalFnNames);

    // STR-3: Overlapping match paths
    for (const rootMatch of rootMatches) {
      checkOverlappingPaths(rootMatch.children, findings);
    }

    // Walk all match blocks
    for (const rootMatch of rootMatches) {
      walkMatch(rootMatch, findings, outerScope, fnScopes, null, isStorage, ast.version);
    }
  }

  return findings;
}

function walkMatch(
  match: MatchBlock,
  findings: ValidationFinding[],
  scopeFunctions: FunctionDef[],
  fnScopes: ReadonlyMap<FunctionDef, ReadonlyMap<string, FunctionDef>>,
  /** Full path segments from the service block down to the parent match block;
   *  null for a top-level match block directly inside `service`. */
  parentRawSegments: readonly PathSegment[] | null = null,
  isStorage = false,
  rulesVersion = '2',
) {
  let rawSegments: PathSegment[];
  if (parentRawSegments === null) {
    rawSegments = [...match.path.segments];
  } else {
    rawSegments = [...parentRawSegments, ...match.path.segments];
  }
  const docSegments = resolveDocumentSegments(rawSegments, rulesVersion, isStorage);
  // SEC-2 and SEC-5 concern a recursive wildcard in the last position, which
  // governs every document under its prefix. One followed by further
  // segments, the collection-group shape, governs only documents whose path
  // ends in them. A root that does not apply to `(default)` resolves to null.
  const subtree = docSegments === null ? null : recursiveScope(docSegments);
  const recursiveSubtree = subtree?.kind === 'subtree' ? subtree : null;
  const pathStr = match.path.raw;

  // Merge scope: parent functions + this match's functions
  const localScope = [...scopeFunctions, ...match.functions];
  const fnMap = new Map(localScope.map((f) => [f.name, f]));

  for (const allow of match.allows) {
    const ops = allow.operations;
    // Fold semantically-constant conditions (e.g. `X || true`, `X && false`,
    // `!true`, ternaries with literal conditions) before the literal checks and
    // the auth/data-reference walks, so tautological rules can't evade SEC-1/2/3
    // and QUA-1 by being written as a binaryOp instead of a bare `true`/`false`.
    const cond = foldConstants(allow.condition, fnMap, fnScopes);
    const isWrite = ops.some((op) => WRITE_OPS.has(op));
    const isRead = ops.some((op) => READ_OPS.has(op));
    const isDataWrite = ops.some((op) => DATA_WRITE_OPS.has(op));
    const isLiteralTrue = cond.type === 'literal' && cond.value === true;
    const isLiteralFalse = cond.type === 'literal' && cond.value === false;
    const hasAuthGuard = guardsAuthTransitive(cond, fnMap, fnScopes);
    const opStr = ops.join(', ');

    // SEC-1: Public write (only when the match path reaches documents/objects)
    if (isWrite && isLiteralTrue && docSegments !== null) {
      findings.push({
        code: 'SEC-1', severity: 'critical', path: pathStr, operation: opStr,
        message: `Public write at ${pathStr} -- anyone can ${opStr} without authentication`,
      });
    }

    // SEC-2: Public read at a final recursive wildcard
    if (isRead && isLiteralTrue && recursiveSubtree) {
      findings.push({
        code: 'SEC-2', severity: 'critical', path: pathStr, operation: opStr,
        message: `Public read at ${recursiveSubtree.fullPath}: ${recursiveSubtree.description} is readable`,
      });
    }

    // SEC-5: A grant at a final recursive wildcard. Downgraded to medium
    // (warning) when the condition requires authentication (#1518); an
    // unauthenticated or open recursive wildcard stays high (error).
    if (recursiveSubtree && !isLiteralFalse) {
      const sec5Severity = hasAuthGuard ? 'medium' : 'high';
      findings.push({
        code: 'SEC-5', severity: sec5Severity, path: pathStr, operation: opStr,
        message: `Recursive wildcard ${recursiveSubtree.fullPath} grants ${opStr} on ${recursiveSubtree.description} `
          + 'when its condition holds; a request is allowed when any matching rule allows it, '
          + 'so a more specific rule cannot narrow this grant',
      });
    }

    // SEC-3: No auth check on write (follows function calls transitively)
    if (docSegments !== null && isWrite && !isLiteralTrue && !isLiteralFalse && !hasAuthGuard) {
      findings.push({
        code: 'SEC-3', severity: 'high', path: pathStr, operation: opStr,
        message: `Write rule (${opStr}) at ${pathStr} does not check request.auth`,
      });
    }

    // SEC-6: Write without payload validation (follows function calls transitively).
    // Downgraded to medium (warning) when the condition requires authentication (#1518);
    // an unauthenticated write without payload validation stays high (error).
    if (docSegments !== null && isDataWrite && !isLiteralFalse && !validatesRequestDataTransitive(cond, fnMap, fnScopes, isStorage)) {
      const sec6Severity = hasAuthGuard ? 'medium' : 'high';
      let sec6Message = `${opStr} at ${pathStr} does not validate request.resource.data -- any data shape accepted`;
      if (isStorage) {
        sec6Message = `${opStr} at ${pathStr} does not validate request.resource (size, contentType, or metadata) -- any upload payload accepted`;
      }
      findings.push({
        code: 'SEC-6', severity: sec6Severity, path: pathStr, operation: opStr,
        message: sec6Message,
      });
    }

    // SEM-1: request.resource.data in read rule (use unfolded condition so short-circuit folding does not hide dead reads)
    if (isRead && referencesRequestDataAnyTransitive(allow.condition, fnMap, fnScopes)) {
      findings.push({
        code: 'SEM-1', severity: 'high', path: pathStr, operation: opStr,
        message: `Read rule at ${pathStr} references request.resource.data which is not available on reads`,
      });
    }

    // SEM-2: resource.data in create/write rule
    const includesCreate = ops.includes('create') || ops.includes('write');
    if (includesCreate && !ops.includes('update') && referencesResourceDataAnyTransitive(allow.condition, fnMap, fnScopes)) {
      findings.push({
        code: 'SEM-2', severity: 'high', path: pathStr, operation: opStr,
        message: `Create rule at ${pathStr} references resource.data but document doesn't exist yet on create`,
      });
    }

    // SEM-3: document access budget exceeded. Production allows exactly 10
    // get/exists/getAfter/existsAfter reads per request evaluation in Firestore
    // and 2 firestore.get/firestore.exists reads in Storage; the next one
    // fails, so the finding fires only ABOVE the limit.
    const maxDocReads = isStorage ? 2 : 10;
    const docReads = countDocumentAccessCalls(allow.condition, fnMap, new Set(), fnScopes, isStorage);
    if (docReads > maxDocReads) {
      let sem3Message =
        `Rule at ${pathStr} may perform ${docReads} document access calls (get/exists/getAfter/existsAfter), which exceeds the ${maxDocReads}-call budget`;
      if (isStorage) {
        sem3Message =
          `Rule at ${pathStr} may perform ${docReads} document access calls (firestore.get/firestore.exists), which exceeds the ${maxDocReads}-call budget`;
      }
      findings.push({
        code: 'SEM-3', severity: 'high', path: pathStr, operation: opStr,
        message: sem3Message,
      });
    }

    // QUA-1: Hardcoded true
    if (isLiteralTrue) {
      const severity = isWrite && docSegments !== null ? 'critical' : 'low';
      findings.push({
        code: 'QUA-1', severity, path: pathStr, operation: opStr,
        message: `Hardcoded 'true' at ${pathStr} for ${opStr}`,
      });
    }

    // QUA-5: Complex condition
    if (exprDepth(allow.condition) > 10) {
      findings.push({
        code: 'QUA-5', severity: 'low', path: pathStr, operation: opStr,
        message: `Condition at ${pathStr} has depth ${exprDepth(allow.condition)} -- consider splitting into functions`,
      });
    }
  }

  // QUA-2: Empty match block
  if (match.allows.length === 0 && match.children.length === 0 && match.functions.length === 0) {
    findings.push({
      code: 'QUA-2', severity: 'low', path: pathStr,
      message: `Match block at ${pathStr} is empty -- no allows, children, or functions`,
    });
  }

  // STR-1: Match without wildcard
  if (match.path.segments.every((s) => s.type === 'literal')) {
    findings.push({
      code: 'STR-1', severity: 'low', path: pathStr,
      message: `Match at ${pathStr} has no wildcard -- matches exactly one document`,
    });
  }

  // STR-2: Nested match without parent rules (skip the root /databases or /b/{bucket}/o match)
  const isRoot =
    (match.path.raw.includes('databases') && match.path.raw.includes('documents')) ||
    (match.path.raw.includes('/b/') && match.path.raw.includes('/o'));
  if (match.children.length > 0 && match.allows.length === 0 && !isRoot) {
    findings.push({
      code: 'STR-2', severity: 'medium', path: pathStr,
      message: `Match at ${pathStr} has nested children but no allows -- parent collection is locked`,
    });
  }

  // Recurse into children
  for (const child of match.children) {
    walkMatch(child, findings, localScope, fnScopes, rawSegments, isStorage, rulesVersion);
  }
}

// ---- SEC-4: Default deny ----

function checkDefaultDeny(
  rootMatches: readonly MatchBlock[],
  findings: ValidationFinding[],
  outerScope: readonly FunctionDef[] = [],
  fnScopes?: ReadonlyMap<FunctionDef, ReadonlyMap<string, FunctionDef>>,
) {
  const coversDeny = (block: MatchBlock, parentScope: readonly FunctionDef[]): boolean => {
    if (block.allows.length === 0) return false;
    const blockFnMap = new Map([...parentScope, ...block.functions].map((f) => [f.name, f]));
    const deniedOps = new Set<Operation>();
    for (const a of block.allows) {
      const folded = foldConstants(a.condition, blockFnMap, fnScopes);
      if (folded.type !== 'literal' || folded.value !== false) return false;
      for (const op of a.operations) deniedOps.add(op);
    }
    const coversRead = deniedOps.has('read') || (deniedOps.has('get') && deniedOps.has('list'));
    const coversWrite =
      deniedOps.has('write') ||
      (deniedOps.has('create') && deniedOps.has('update') && deniedOps.has('delete'));
    return coversRead && coversWrite;
  };

  const hasDefaultDeny = rootMatches.some((rootMatch) => {
    const rootScope = [...outerScope, ...rootMatch.functions];
    const lastSeg = rootMatch.path.segments[rootMatch.path.segments.length - 1];
    const isRootWithTrailingRecursive =
      ((rootMatch.path.raw.includes('databases') && rootMatch.path.raw.includes('documents')) ||
        (rootMatch.path.raw.includes('/b/') && rootMatch.path.raw.includes('/o'))) &&
      lastSeg?.type === 'recursive';
    return (
      (isRootWithTrailingRecursive && coversDeny(rootMatch, outerScope)) ||
      rootMatch.children.some((child) => {
        const isWholeDbWildcard =
          child.path.segments.length === 1 && child.path.segments[0]?.type === 'recursive';
        return isWholeDbWildcard && coversDeny(child, rootScope);
      })
    );
  });

  if (!hasDefaultDeny) {
    findings.push({
      code: 'SEC-4', severity: 'medium', path: '/',
      message: 'No default deny rule (match /{document=**} { allow read, write: if false; })',
    });
  }
}

// ---- QUA-3: Duplicate functions ----

function checkDuplicateFunctions(
  ast: FirestoreRules,
  findings: ValidationFinding[],
  isSecondaryService = false,
) {
  for (const violation of compileLimitViolations(ast, { allowUnresolvedImports: true })) {
    if (violation.code !== 'FUNCTION_REDEFINED') continue;
    if (isSecondaryService && violation.scope === 'global scope') continue;
    findings.push({
      code: 'QUA-3', severity: 'critical', path: violation.scope ?? '',
      message: `${violation.message} Function '${violation.functionName}' is declared twice in ${violation.scope}, and production rejects the ruleset at compile time`,
    });
  }
}

// ---- SEM-4, SEM-5, QUA-4: name resolution ----

function checkNameResolution(
  scopes: RulesetScopes,
  findings: ValidationFinding[],
  isSecondaryService = false,
  calledGlobalFnNames?: ReadonlySet<string>,
) {
  const called = new Set<FunctionDef>();
  const report = (
    refs: NameReferences,
    subject: string,
    path: string,
    operation?: string,
    emitFindings = true,
  ) => {
    for (const callee of refs.callees) called.add(callee);
    if (!emitFindings) return;
    for (const name of refs.undefinedCalls) {
      const finding: ValidationFinding = {
        code: 'SEM-4', severity: 'high', path,
        message: `${subject} calls undefined function '${name}'`,
      };
      if (operation !== undefined) finding.operation = operation;
      findings.push(finding);
    }
    for (const name of refs.unboundVariables) {
      const finding: ValidationFinding = {
        code: 'SEM-5', severity: 'high', path,
        message: `${subject} reads unbound variable '${name}'. No let binding, function parameter, path capture, or rules global has that name, so evaluating it is an error and the request is denied`,
      };
      if (operation !== undefined) finding.operation = operation;
      findings.push(finding);
    }
  };
  for (const scoped of scopes.rules) {
    report(ruleReferences(scoped), `Rule at ${scoped.label}`, scoped.label, scoped.rule.operations.join(', '));
  }
  for (const scoped of scopes.functions) {
    const emit = !(isSecondaryService && scoped.label === 'global scope');
    report(functionReferences(scoped), `Function '${scoped.fn.name}' in ${scoped.label}`, scoped.label, undefined, emit);
  }
  for (const scoped of scopes.functions) {
    if (isSecondaryService && scoped.label === 'global scope') continue;
    if (called.has(scoped.fn)) continue;
    if (scoped.label === 'global scope' && calledGlobalFnNames?.has(scoped.fn.name)) continue;
    findings.push({
      code: 'QUA-4', severity: 'low', path: scoped.label,
      message: `Unused function '${scoped.fn.name}': no rule or function calls it`,
    });
  }
}

// ---- STR-3: Overlapping paths ----

function checkOverlappingPaths(siblings: MatchBlock[], findings: ValidationFinding[]) {
  for (let i = 0; i < siblings.length; i++) {
    const first = siblings[i];
    if (first === undefined) continue;
    for (let j = i + 1; j < siblings.length; j++) {
      const second = siblings[j];
      if (second === undefined) continue;
      if (pathsOverlap(first, second)) {
        findings.push({
          code: 'STR-3', severity: 'low', path: first.path.raw,
          message: `Match paths '${first.path.raw}' and '${second.path.raw}' may overlap -- the more permissive one wins`,
        });
      }
    }
    checkOverlappingPaths(first.children, findings);
  }
}

function pathsOverlap(a: MatchBlock, b: MatchBlock): boolean {
  const segsA = a.path.segments;
  const segsB = b.path.segments;
  if (segsA.length !== segsB.length) return false;
  for (let i = 0; i < segsA.length; i++) {
    const sa = segsA[i];
    const sb = segsB[i];
    if (sa === undefined || sb === undefined) return false;
    if (sa.type === 'literal' && sb.type === 'literal' && sa.value !== sb.value) return false;
    if ((sa.type === 'wildcard' || sa.type === 'recursive') && sb.type === 'literal') return true;
    if (sa.type === 'literal' && (sb.type === 'wildcard' || sb.type === 'recursive')) return true;
  }
  return false;
}
