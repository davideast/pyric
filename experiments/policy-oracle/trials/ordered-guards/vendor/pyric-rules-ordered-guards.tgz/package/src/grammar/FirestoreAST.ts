/** Typed AST for Firestore Security Rules. */

/** 1-indexed source position. `col` is 1-indexed too. */
export interface SourceLoc {
  line: number;
  col: number;
  file?: string;
}

export interface ImportDecl {
  functions: string[];
  module: string;
  loc?: SourceLoc;
}

export interface FirestoreRules {
  version: string;
  imports: ImportDecl[];
  /** Functions declared at global scope (between the header lines and the
   *  service block). Visible everywhere inside the service. Absent on ASTs
   *  constructed programmatically. */
  functions?: FunctionDef[];
  /** The service the ruleset governs: the file's `cloud.firestore` block,
   *  or its first block when it has none. */
  service: ServiceBlock;
  /** Every service block in the file, in source order, `service` among
   *  them. Absent on ASTs constructed programmatically. */
  services?: ServiceBlock[];
  loc?: SourceLoc;
}

export interface ServiceBlock {
  name: string;
  /** Functions declared directly inside `service { }`, outside any match.
   *  Visible everywhere inside the service. Absent on ASTs constructed
   *  programmatically. */
  functions?: FunctionDef[];
  match: MatchBlock;
  /** All top-level match blocks in source order (`match` is `matches[0]`). */
  matches?: MatchBlock[];
  loc?: SourceLoc;
}

export interface MatchBlock {
  path: PathPattern;
  functions: FunctionDef[];
  allows: AllowRule[];
  children: MatchBlock[];
  /** Source position of the `match` keyword. Populated by the parser;
   *  absent on blocks constructed programmatically. Used by the
   *  path-resolution trace to attribute "near-miss" blocks to their
   *  source line. */
  loc?: SourceLoc;
}

export interface PathPattern {
  raw: string;
  segments: PathSegment[];
}

export type PathSegment =
  | { type: 'literal'; value: string }
  | { type: 'wildcard'; name: string }
  | { type: 'recursive'; name: string };

export interface AllowRule {
  operations: Operation[];
  condition: Expression;
  /** Source position of the `allow` keyword. Populated by the parser;
   *  absent on rules constructed programmatically (e.g. lint test fixtures). */
  loc?: SourceLoc;
}

export type Operation = 'read' | 'write' | 'get' | 'list' | 'create' | 'update' | 'delete';

export interface FunctionDef {
  name: string;
  parameters: string[];
  exported: boolean;
  lets: LetBinding[];
  body: Expression;
  /** Source position of the `function` keyword. */
  loc?: SourceLoc;
  /** Source position of the return expression, the first token after `return`. */
  returnLoc?: SourceLoc;
}

export interface LetBinding {
  name: string;
  value: Expression;
  loc?: SourceLoc;
}

export type Expression =
  | { type: 'literal'; value: string | number | boolean | null | Uint8Array; raw: string; loc?: SourceLoc }
  | { type: 'identifier'; name: string; loc?: SourceLoc }
  | { type: 'memberAccess'; object: Expression; property: string; loc?: SourceLoc }
  | { type: 'methodCall'; object: Expression; method: string; args: Expression[]; loc?: SourceLoc }
  | { type: 'bracketAccess'; object: Expression; index: Expression; loc?: SourceLoc }
  | { type: 'sliceAccess'; object: Expression; start: Expression; end: Expression; loc?: SourceLoc }
  | {
    type: 'binaryOp'; op: string; left: Expression; right: Expression; loc?: SourceLoc;
    /** Set on a `/` directly followed by a character other than whitespace,
     *  which production reads as the start of a path (see compile-limits). */
    slashStartsPath?: true;
  }
  | { type: 'unaryOp'; op: string; operand: Expression; loc?: SourceLoc }
  | { type: 'ternary'; condition: Expression; consequent: Expression; alternate: Expression; loc?: SourceLoc }
  | { type: 'inExpr'; element: Expression; collection: Expression; loc?: SourceLoc }
  | { type: 'isExpr'; value: Expression; typeName: string; loc?: SourceLoc }
  | { type: 'listLiteral'; elements: Expression[]; loc?: SourceLoc }
  | { type: 'mapLiteral'; entries: Array<{ key: Expression; value: Expression }>; loc?: SourceLoc }
  | {
    type: 'pathLiteral';
    raw: string;
    segments: Array<string | Expression>;
    /** Set when this path literal represents a substituted DocumentReference value in residual proof. */
    isReference?: true;
    loc?: SourceLoc;
  }
  | { type: 'functionCall'; name: string; args: Expression[]; loc?: SourceLoc };

