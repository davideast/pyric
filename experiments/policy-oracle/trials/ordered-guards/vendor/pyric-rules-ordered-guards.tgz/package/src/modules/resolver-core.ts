/**
 * Pure `2+modules` resolution core — NO node imports. Disk access is
 * injected via {@link ModuleFileReader} so browser bundles that reach this
 * module (via `resolver-browser.js`, the simulator wiring, or rules tools)
 * never pull `fs`/`path`/`url`. The node-flavored public API
 * (`resolveModules` with real disk reads) lives in `./resolver.js`.
 */
import { parseToASTOrError, parseFunctions } from '../grammar/FirestoreParser.js';
import { assembleRules, assembleRulesWithSourceMap, type RulesSourceMapEntry } from '../grammar/FirestoreAssembler.js';
import type { FunctionDef, Expression, FirestoreRules, MatchBlock } from '../grammar/FirestoreAST.js';
import { RULES_BUILTIN_FUNCTIONS } from '../grammar/builtin-functions.js';
import { allServiceBlocks, isStorageServiceName, topLevelMatches } from '../grammar/service-blocks.js';
import { DUPLICATE_SERVICE_REASON, duplicateServiceRejection } from '../grammar/source-compile-limits.js';
import { STDLIB_MODULE_EVIDENCE } from './stdlib-services.generated.js';
import {
  incompatibleFunction,
  incompatibleStdlibExport,
} from './service-compatibility.js';
import {
  prefixPrivateFunctions,
  rewriteCalls,
  sanitizeModuleName,
} from './resolver-transform.js';
import {
  collectFunctionCalls,
  moduleCallSites,
  type ModuleCallSite,
} from './resolver-call-sites.js';
export {
  prefixPrivateFunctions,
  rewriteCalls,
  sanitizeModuleName,
} from './resolver-transform.js';
export { STDLIB_SERVICE_CONTRACT_MODULES } from './service-compatibility.js';

function assertNever(value: never): never {
  throw new Error(`Unhandled Rules expression: ${JSON.stringify(value)}`);
}

/**
 * Injectable disk access for the two load paths that read files: relative
 * imports (priority 2) and the on-disk stdlib fallback (priority 5). The
 * node entry (`./resolver.js`) supplies a real reader; browser consumers
 * (`./resolver-browser.js`) pass `null` — they pre-supply every module via
 * `options.modules`, so the disk paths are unreachable there by
 * construction, and this module stays free of `fs`/`path`/`url` imports
 * (they used to leak into browser bundles through the static import chain).
 */
export interface ModuleFileReader {
  /** Read `<basePath>/<moduleName>.rules` (or an explicit `.rules` path). Null when unreadable. */
  readRelative(basePath: string, moduleName: string): string | null;
  /** Read `<stdlib>/<moduleName>.rules` from the package's on-disk stdlib.
   *  Null when unreadable. */
  readStdlib(moduleName: string): string | null;
}

export type ResolveResult =
  | { success: true; data: {
    resolved: string;
    modules: string[];
    bundledModules: string[];
    evidenceIds: string[];
    sourceMap?: RulesSourceMapEntry[];
  } }
  | { success: false; error: { code: string; message: string } };

export interface ResolveOptions {
  basePath?: string;
  modules?: Record<string, string>;
  sourceFile?: string;
  targetService?: 'cloud.firestore' | 'firebase.storage';
}

/** An import declaration: the module specifier as written, and the names it requests. */
export interface ModuleImport {
  module: string;
  functions: string[];
}

type LoadResult =
  | { success: true; functions: FunctionDef[]; imports: ModuleImport[]; bundled: boolean }
  | { success: false; error: { code: string; message: string } };

// ---- Function call collection (for transitive deps) ----

function collectCalls(expr: Expression): string[] {
  return collectFunctionCalls(expr).map(({ name }) => name);
}

function functionCallSites(
  functions: ReadonlyMap<string, FunctionDef>,
  functionName: string,
): readonly Expression[][] {
  const expressions = [...functions.values()].flatMap((fn) => [
    ...fn.lets.map(({ value }) => value),
    fn.body,
  ]);
  return expressions.flatMap(collectFunctionCalls)
    .filter(({ name }) => name === functionName)
    .map(({ args }) => args);
}

// ---- Module loading ----

const MODULE_TRIVIA = /^(?:\s+|\/\/[^\n]*|\/\*[\s\S]*?\*\/)/;
const MODULE_IDENT = /^[A-Za-z_][A-Za-z0-9_]*/;
const MODULE_STRING = /^(['"])([^'"]*)\1/;
const MISPLACED_DECLARATION = /^\s*(?:import(?:\s|\/\*[\s\S]*?\*\/|\/\/[^\n]*\n)*\{|rules_version\b)/m;

/** Replace every character except newlines with a space, so source locations stay put. */
function blankOut(text: string): string {
  return text.replace(/[^\n]/g, ' ');
}

function skipModuleTrivia(text: string, start: number): number {
  let pos = start;
  while (pos < text.length) {
    const trivia = MODULE_TRIVIA.exec(text.slice(pos));
    if (!trivia || trivia[0].length === 0) break;
    pos += trivia[0].length;
  }
  return pos;
}

function scanModuleVersion(text: string, start: number): { end: number; version: string } | null {
  if (!/^rules_version\b/.test(text.slice(start))) return null;
  let pos = skipModuleTrivia(text, start + 'rules_version'.length);
  if (text[pos] !== '=') return null;
  pos = skipModuleTrivia(text, pos + 1);
  const str = MODULE_STRING.exec(text.slice(pos));
  if (!str) return null;
  pos = skipModuleTrivia(text, pos + str[0].length);
  if (text[pos] !== ';') return null;
  return { end: pos + 1, version: str[2] };
}

function scanModuleImport(text: string, start: number): { end: number; module: string; functions: string[] } | null {
  if (!/^import\b/.test(text.slice(start))) return null;
  let pos = skipModuleTrivia(text, start + 'import'.length);
  if (text[pos] !== '{') return null;
  pos = skipModuleTrivia(text, pos + 1);
  const functions: string[] = [];
  while (pos < text.length && text[pos] !== '}') {
    const ident = MODULE_IDENT.exec(text.slice(pos));
    if (!ident) return null;
    functions.push(ident[0]);
    pos = skipModuleTrivia(text, pos + ident[0].length);
    if (text[pos] === ',') {
      pos = skipModuleTrivia(text, pos + 1);
    } else {
      break;
    }
  }
  if (text[pos] !== '}') return null;
  pos = skipModuleTrivia(text, pos + 1);
  if (!/^from\b/.test(text.slice(pos))) return null;
  pos = skipModuleTrivia(text, pos + 'from'.length);
  const str = MODULE_STRING.exec(text.slice(pos));
  if (!str || str[2] === '') return null;
  pos = skipModuleTrivia(text, pos + str[0].length);
  if (text[pos] !== ';') return null;
  return { end: pos + 1, module: str[2], functions };
}

/**
 * Split a module file into its header (an optional rules_version line and
 * import declarations, before any function) and its functions. The header is
 * blanked out rather than removed, so function source lines are unchanged.
 */
function splitModuleHeader(
  content: string,
  moduleName: string,
): { success: true; body: string; imports: ModuleImport[] } | { success: false; error: { code: string; message: string } } {
  const imports: ModuleImport[] = [];
  let body = content;
  let cursor = 0;
  for (;;) {
    cursor = skipModuleTrivia(content, cursor);
    const version = scanModuleVersion(content, cursor);
    if (version) {
      if (version.version !== '2+modules') {
        return {
          success: false,
          error: {
            code: 'NOT_MODULE_SOURCE',
            message: `Module '${moduleName}' declares rules_version '${version.version}'; a module's version is '2+modules'`,
          },
        };
      }
      body = body.slice(0, cursor) + blankOut(content.slice(cursor, version.end)) + body.slice(version.end);
      cursor = version.end;
      continue;
    }
    const declaration = scanModuleImport(content, cursor);
    if (declaration) {
      imports.push({ module: declaration.module, functions: declaration.functions });
      body = body.slice(0, cursor) + blankOut(content.slice(cursor, declaration.end)) + body.slice(declaration.end);
      cursor = declaration.end;
      continue;
    }
    return { success: true, body, imports };
  }
}

function loadModuleFromContent(content: string, moduleName: string, bundled: boolean): LoadResult {
  const header = splitModuleHeader(content, moduleName);
  if (!header.success) return header;
  const functions = parseFunctions(header.body, moduleName);
  const isFunctionsNull = functions === null;
  if (isFunctionsNull) {
    const message = MISPLACED_DECLARATION.test(header.body)
      ? `Failed to parse module '${moduleName}': a module puts rules_version and imports before its first function`
      : `Failed to parse module '${moduleName}'`;
    return { success: false, error: { code: 'PARSE_FAILED', message } };
  }
  return { success: true, functions: functions!, imports: header.imports, bundled };
}

/**
 * The specifier of a module imported from inside another module. A relative
 * import resolves from the importing module's directory; stdlib names and
 * imports written in the source are returned unchanged.
 */
function resolveSpecifier(importer: string | null, specifier: string): string {
  if (importer === null || !isRelativeImport(specifier) || !isRelativeImport(importer)) return specifier;
  const segments: string[] = [];
  for (const part of [...importer.split('/').slice(0, -1), ...specifier.split('/')]) {
    if (part === '.' || part === '') continue;
    const canPop = segments.length > 0 && segments[segments.length - 1] !== '..';
    if (part === '..' && canPop) segments.pop();
    else segments.push(part);
  }
  const joined = segments.join('/');
  return joined.startsWith('..') ? joined : `./${joined}`;
}

function isRelativeImport(moduleName: string): boolean {
  return moduleName.startsWith('./') || moduleName.startsWith('../');
}

function conventionalStdlibKey(moduleName: string): string | null {
  return /^\.\/stdlib\/([A-Za-z0-9_-]+(?:\/[A-Za-z0-9_-]+)*)(?:\.rules)?$/
    .exec(moduleName)?.[1] ?? null;
}

function stripRulesExtension(moduleName: string): string {
  return moduleName.endsWith('.rules') ? moduleName.slice(0, -'.rules'.length) : moduleName;
}

function findExplicitModuleEntry(
  modules: Record<string, string>,
  moduleName: string,
): { canonicalKey: string; lookupKey: string } | null {
  const hasExact = Object.prototype.hasOwnProperty.call(modules, moduleName);
  if (isRelativeImport(moduleName) && !conventionalStdlibKey(moduleName)) {
    const withoutExt = stripRulesExtension(moduleName);
    const withExt = `${withoutExt}.rules`;
    const hasWithout = Object.prototype.hasOwnProperty.call(modules, withoutExt);
    const hasWith = Object.prototype.hasOwnProperty.call(modules, withExt);
    if (hasWithout && hasWith && modules[withoutExt] !== modules[withExt]) {
      return hasExact ? { canonicalKey: moduleName, lookupKey: moduleName } : null;
    }
    if (hasExact) {
      return { canonicalKey: withoutExt, lookupKey: moduleName };
    }
    const alt = moduleName.endsWith('.rules') ? withoutExt : withExt;
    if (Object.prototype.hasOwnProperty.call(modules, alt)) {
      return { canonicalKey: withoutExt, lookupKey: alt };
    }
    return null;
  }
  return hasExact ? { canonicalKey: moduleName, lookupKey: moduleName } : null;
}

function canonicalModuleKey(
  reader: ModuleFileReader | null,
  moduleName: string,
  options?: ResolveOptions,
  bundledSuppliedModules: ReadonlySet<string> = new Set(),
): string {
  if (options?.modules) {
    const explicit = findExplicitModuleEntry(options.modules, moduleName);
    if (explicit) {
      if (!bundledSuppliedModules.has(explicit.lookupKey)) return explicit.canonicalKey;
      return conventionalStdlibKey(moduleName) ?? explicit.canonicalKey;
    }
  }
  if (isRelativeImport(moduleName) && options?.basePath) {
    if ((reader?.readRelative(options.basePath, moduleName) ?? null) !== null) {
      return stripRulesExtension(moduleName);
    }
  }
  return conventionalStdlibKey(moduleName) ?? moduleName;
}

export function loadModuleWith(
  reader: ModuleFileReader | null,
  moduleName: string,
  options?: ResolveOptions,
  bundledSuppliedModules: ReadonlySet<string> = new Set(),
): LoadResult {
  // Priority 1: explicit modules map
  if (options?.modules) {
    const explicit = findExplicitModuleEntry(options.modules, moduleName);
    if (explicit) {
      return loadModuleFromContent(
        options.modules[explicit.lookupKey],
        moduleName,
        bundledSuppliedModules.has(explicit.lookupKey),
      );
    }
  }

  // Priority 2: relative path from basePath
  if (isRelativeImport(moduleName) && options?.basePath) {
    const filePath = `${options.basePath}/${moduleName}${moduleName.endsWith('.rules') ? '' : '.rules'}`;
    const content = reader?.readRelative(options.basePath, moduleName) ?? null;
    if (content !== null) return loadModuleFromContent(content, moduleName, false);
    if (!conventionalStdlibKey(moduleName)) {
      return { success: false, error: { code: 'UNKNOWN_MODULE', message: `Module '${moduleName}' not found at ${filePath}` } };
    }
  }

  // Priority 3: conventional stdlib path alias. An explicit modules entry or
  // a real basePath file still wins; only an unresolved alias reaches here.
  const stdlibKey = conventionalStdlibKey(moduleName);
  if (stdlibKey) {
    if (options?.modules && Object.prototype.hasOwnProperty.call(options.modules, stdlibKey)) {
      return loadModuleFromContent(
        options.modules[stdlibKey], moduleName, bundledSuppliedModules.has(stdlibKey),
      );
    }
    const content = reader?.readStdlib(stdlibKey) ?? null;
    if (content === null) {
      return { success: false, error: { code: 'UNKNOWN_MODULE', message: `Module '${moduleName}' not found` } };
    }
    return loadModuleFromContent(content, moduleName, true);
  }

  // Priority 4: relative path without basePath
  if (isRelativeImport(moduleName)) {
    return { success: false, error: { code: 'UNKNOWN_MODULE', message: `Module '${moduleName}' requires basePath for relative imports` } };
  }

  // Priority 5: stdlib (on disk — node only; browser callers pre-supply
  // stdlib via options.modules and never reach here for known modules)
  const content = reader?.readStdlib(moduleName) ?? null;
  if (content === null) {
    return { success: false, error: { code: 'UNKNOWN_MODULE', message: `Module '${moduleName}' not found` } };
  }
  return loadModuleFromContent(content, moduleName, true);
}

// ---- Main resolver ----

export function resolveModulesWith(
  reader: ModuleFileReader | null,
  source: string,
  options?: ResolveOptions,
  bundledSuppliedModules: ReadonlySet<string> = new Set(),
): ResolveResult {
  // 1. Parse source
  const parsed = parseToASTOrError(source);
  if (!parsed.ok) {
    const { line, column, message } = parsed.error;
    return {
      success: false,
      error: {
        code: 'PARSE_FAILED',
        message: `Failed to parse source at line ${line}, col ${column}: ${message}`,
      },
    };
  }
  const ast = parsed.ast;
  // The resolved source is rebuilt from `ast.service` alone, so a second
  // block for one service is refused here, before it is dropped.
  const duplicate = duplicateServiceRejection(ast);
  if (duplicate !== null) {
    return {
      success: false,
      error: {
        code: 'PARSE_FAILED',
        message: `Source did not compile at line ${duplicate.line}, col ${duplicate.column}: ${DUPLICATE_SERVICE_REASON}`,
      },
    };
  }
  if (options?.targetService !== undefined) {
    const selected = (ast.services ?? [ast.service]).find((block) => {
      if (options.targetService === 'firebase.storage') {
        return isStorageServiceName(block.name);
      }
      return block.name === options.targetService;
    });
    if (selected !== undefined) ast.service = selected;
  }
  const isModular = ast.version === '2+modules';
  const isStorageService = isStorageServiceName(ast.service.name);
  let sourceFile = 'firestore.rules';
  if (isStorageService) {
    sourceFile = 'storage.rules';
  }
  if (isModular) {
    sourceFile = 'firestore.modules.rules';
    if (isStorageService) {
      sourceFile = 'storage.modules.rules';
    }
  }
  const hasOptions = options !== undefined;
  if (hasOptions) {
    const hasSourceFile = options!.sourceFile !== undefined;
    if (hasSourceFile) {
      const isNotEmpty = options!.sourceFile !== '';
      if (isNotEmpty) {
        sourceFile = options!.sourceFile!;
      }
    }
  }
  attachAstSourceFile(ast, sourceFile);

  // 2. Check for module version (exact match)
  if (isModular === false) {
    return { success: false, error: { code: 'NOT_MODULE_SOURCE', message: `Version '${ast.version}' is not a module source` } };
  }

  const isFirestore = ast.service.name === 'cloud.firestore';
  if (isFirestore === false) {
    const isStorage = isStorageServiceName(ast.service.name);
    if (isStorage === false) {
      return {
        success: false,
        error: {
          code: 'UNSUPPORTED_SERVICE',
          message: `Module resolution does not support service '${ast.service.name}'`,
        },
      };
    }
  }

  const topLevelSourceFnNames = new Set([
    ...(ast.functions ?? []).map((fn) => fn.name),
    ...(ast.service.functions ?? []).map((fn) => fn.name),
  ]);
  const sourceFnNames = new Set(topLevelSourceFnNames);
  const collectMatchFunctions = (match: typeof ast.service.match): void => {
    match.functions.forEach((fn) => sourceFnNames.add(fn.name));
    match.children.forEach(collectMatchFunctions);
  };
  for (const rootMatch of topLevelMatches(ast.service)) {
    collectMatchFunctions(rootMatch);
  }
  const builtinSourceCollision = [...sourceFnNames]
    .find((name) => RULES_BUILTIN_FUNCTIONS.has(name));
  if (builtinSourceCollision) {
    return {
      success: false,
      error: {
        code: 'DUPLICATE_FUNCTION',
        message: `Source function '${builtinSourceCollision}' conflicts with a Rules builtin`,
      },
    };
  }

  const isNoImports = ast.imports.length === 0;
  if (isNoImports) {
    ast.version = '2';
    clearExportedModifiers(ast);
    const assembled = assembleRulesWithSourceMap(ast);
    const sourceMapJson = JSON.stringify(assembled.sourceMap);
    const resolvedWithMap = `${assembled.resolved}// @pyric-source-map: ${sourceMapJson}\n`;
    return { success: true, data: {
      resolved: resolvedWithMap,
      modules: [],
      bundledModules: [],
      evidenceIds: [],
      sourceMap: assembled.sourceMap,
    } };
  }

  const emptyImport = ast.imports.find((imp) => imp.functions.length === 0);
  if (emptyImport) {
    return {
      success: false,
      error: {
        code: 'UNKNOWN_FUNCTION',
        message: `Import from '${emptyImport.module}' must request at least one function`,
      },
    };
  }

  // 3. Load all modules and collect exported functions + all functions (for transitive deps)
  const functionsPerModule = new Map<string, Map<string, FunctionDef>>();
  const anyModuleFunctionOrigin = new Map<string, string>();
  const displayNamePerModule = new Map<string, string>();
  const functionOrigin = new Map<string, string>();
  const modulesUsed: string[] = [];
  const bundledModulesUsed: string[] = [];
  const privateNamesPerModule = new Map<string, Set<string>>();
  const usedModulePrefixes = new Set<string>();
  const modulePrefixPerModule = new Map<string, string>();

  // Imports written in the source come first. A module's own imports are
  // queued when its file loads, and each module file loads once.
  const exportsPerModule = new Map<string, Set<string>>();
  const bundledPerModule = new Map<string, boolean>();
  const importsPerModule = new Map<string, Map<string, string>>();
  const rootImports = new Map<string, string>();
  const pending: Array<ModuleImport & { importer: string | null }> = ast.imports
    .map((imp) => ({ module: imp.module, functions: imp.functions, importer: null }));

  for (let imp = pending.shift(); imp !== undefined; imp = pending.shift()) {
    const modKey = canonicalModuleKey(reader, imp.module, options, bundledSuppliedModules);

    if (!exportsPerModule.has(modKey)) {
      const loaded = loadModuleWith(reader, imp.module, options, bundledSuppliedModules);
      if (!loaded.success) {
        return { success: false, error: loaded.error };
      }
      modulesUsed.push(imp.module);
      displayNamePerModule.set(modKey, imp.module);
      bundledPerModule.set(modKey, loaded.bundled);
      if (loaded.bundled) bundledModulesUsed.push(imp.module);
      for (const nested of loaded.imports) {
        if (nested.functions.length === 0) {
          return {
            success: false,
            error: {
              code: 'UNKNOWN_FUNCTION',
              message: `Import from '${nested.module}' in module '${imp.module}' must request at least one function`,
            },
          };
        }
        pending.push({ ...nested, module: resolveSpecifier(imp.module, nested.module), importer: modKey });
      }

      const originalNames = new Set<string>();
      const originalCollision = loaded.functions.find((fn) => {
        if (originalNames.has(fn.name)) return true;
        originalNames.add(fn.name);
        return false;
      });
      if (originalCollision) {
        return {
          success: false,
          error: {
            code: 'DUPLICATE_FUNCTION',
            message: `Module '${imp.module}' defines duplicate function '${originalCollision.name}'`,
          },
        };
      }

      const builtinCollision = loaded.functions
        .find((fn) => RULES_BUILTIN_FUNCTIONS.has(fn.name));
      if (builtinCollision) {
        return {
          success: false,
          error: {
            code: 'DUPLICATE_FUNCTION',
            message: `Function '${builtinCollision.name}' from module '${imp.module}' conflicts with a Rules builtin`,
          },
        };
      }

      // Track original private names before prefixing (for error messages)
      const privateNames = new Set<string>();
      for (const fn of loaded.functions) {
        if (!fn.exported) privateNames.add(fn.name);
      }
      privateNamesPerModule.set(modKey, privateNames);

      const basePrefix = sanitizeModuleName(imp.module);
      let modulePrefix = basePrefix;
      let prefixIndex = 2;
      while (
        usedModulePrefixes.has(modulePrefix)
        || loaded.functions.some((fn) =>
          !fn.exported
          && (
            sourceFnNames.has(`${modulePrefix}__${fn.name}`)
            || anyModuleFunctionOrigin.has(`${modulePrefix}__${fn.name}`)
          ))
      ) {
        modulePrefix = `${basePrefix}_${prefixIndex}`;
        prefixIndex += 1;
      }
      usedModulePrefixes.add(modulePrefix);
      modulePrefixPerModule.set(modKey, modulePrefix);

      const prefixed = prefixPrivateFunctions(loaded.functions, imp.module, modulePrefix);
      const namesInModule = new Map<string, FunctionDef>();
      for (const fn of prefixed) {
        if (namesInModule.has(fn.name)) {
          return {
            success: false,
            error: {
              code: 'DUPLICATE_FUNCTION',
              message: `Module '${imp.module}' defines conflicting function name '${fn.name}'`,
            },
          };
        }
        namesInModule.set(fn.name, fn);
        if (!anyModuleFunctionOrigin.has(fn.name)) {
          anyModuleFunctionOrigin.set(fn.name, imp.module);
        }
      }
      const moduleExports = new Set(
        prefixed.filter((fn) => fn.exported).map((fn) => fn.name),
      );
      functionsPerModule.set(modKey, namesInModule);
      exportsPerModule.set(modKey, moduleExports);
    }
    const moduleExports = exportsPerModule.get(modKey)!;
    const modDisplayName = displayNamePerModule.get(modKey) ?? imp.module;

    // Verify all requested functions exist AND are exported
    for (const fnName of imp.functions) {
      if (!moduleExports.has(fnName)) {
        const isPrivate = privateNamesPerModule.get(modKey)?.has(fnName);
        const msg = isPrivate
          ? `Function '${fnName}' in module '${imp.module}' is not exported`
          : `Function '${fnName}' not found in module '${imp.module}'`;
        return { success: false, error: { code: 'UNKNOWN_FUNCTION', message: msg } };
      }
      if (ast.service.name === 'cloud.firestore' || isStorageService) {
        let canonicalService: 'cloud.firestore' | 'firebase.storage' = 'cloud.firestore';
        if (isStorageService) {
          canonicalService = 'firebase.storage';
        }
        let message: string | null = null;
        if (bundledPerModule.get(modKey)) {
          message = incompatibleStdlibExport(canonicalService, imp.module, fnName);
        }
        if (message) {
          return { success: false, error: { code: 'INCOMPATIBLE_FUNCTION', message } };
        }
      }
      if (imp.importer === null) {
        const existingMod = rootImports.get(fnName);
        if (existingMod !== undefined && existingMod !== modKey) {
          return {
            success: false,
            error: {
              code: 'DUPLICATE_FUNCTION',
              message: `Function '${fnName}' exported by both '${displayNamePerModule.get(existingMod)}' and '${modDisplayName}'`,
            },
          };
        }
        rootImports.set(fnName, modKey);
      } else {
        const modImports = importsPerModule.get(imp.importer) ?? new Map<string, string>();
        const existingMod = modImports.get(fnName);
        if (existingMod !== undefined && existingMod !== modKey) {
          return {
            success: false,
            error: {
              code: 'DUPLICATE_FUNCTION',
              message: `Function '${fnName}' exported by both '${displayNamePerModule.get(existingMod)}' and '${modDisplayName}'`,
            },
          };
        }
        modImports.set(fnName, modKey);
        importsPerModule.set(imp.importer, modImports);
      }
    }
  }

  const requestedNames = new Set(ast.imports.flatMap((imp) => imp.functions));
  // 4. Validate the reachable call graph while building dependency-first order.
  const injectedEntries: Array<{ modKey: string; fn: FunctionDef }> = [];
  const visitedNodes = new Set<string>();
  const visiting: Array<{ modKey: string; fnName: string }> = [];
  const traversal: {
    cycle: string[] | null;
    error: { code: string; message: string } | null;
  } = { cycle: null, error: null };

  function addWithDeps(modKey: string, fnName: string): void {
    if (traversal.cycle || traversal.error) return;
    const cycleStart = visiting.findIndex((v) => v.modKey === modKey && v.fnName === fnName);
    if (cycleStart >= 0) {
      traversal.cycle = [...visiting.slice(cycleStart).map((v) => v.fnName), fnName];
      return;
    }
    const nodeKey = `${modKey}\0${fnName}`;
    if (visitedNodes.has(nodeKey)) return;
    const fn = functionsPerModule.get(modKey)?.get(fnName);
    if (!fn) return;
    visiting.push({ modKey, fnName });
    const calls = [...fn.lets.flatMap(({ value }) => collectCalls(value)), ...collectCalls(fn.body)];
    const ownFunctions = functionsPerModule.get(modKey);
    const ownImports = importsPerModule.get(modKey);
    for (const call of calls) {
      if (RULES_BUILTIN_FUNCTIONS.has(call)) continue;
      if (ownFunctions?.has(call)) {
        addWithDeps(modKey, call);
      } else if (ownImports?.has(call)) {
        addWithDeps(ownImports.get(call)!, call);
      } else if (anyModuleFunctionOrigin.has(call)) {
        traversal.error = {
          code: 'UNKNOWN_FUNCTION',
          message: `Function '${fn.name}' in module '${displayNamePerModule.get(modKey)}' cannot call '${call}' from another module`,
        };
        visiting.pop();
        return;
      }
      if (traversal.cycle || traversal.error) {
        visiting.pop();
        return;
      }
    }
    visiting.pop();
    if (traversal.cycle || traversal.error) return;
    visitedNodes.add(nodeKey);
    functionOrigin.set(fnName, modKey);
    injectedEntries.push({ modKey, fn: { ...fn, exported: false } });
  }

  for (const imp of ast.imports) {
    const modKey = canonicalModuleKey(reader, imp.module, options, bundledSuppliedModules);
    for (const fnName of imp.functions) {
      addWithDeps(modKey, fnName);
    }
  }
  if (traversal.cycle) {
    return {
      success: false,
      error: {
        code: 'CIRCULAR_DEPENDENCY',
        message: `Recursive module function dependency: ${traversal.cycle.join(' -> ')}`,
      },
    };
  }
  if (traversal.error) {
    return {
      success: false,
      error: traversal.error,
    };
  }

  // Prefix any reachable non-root-imported module export whose bare name would
  // collide with a source function declaration or another injected function.
  const claimedInjectedNames = new Set<string>(requestedNames);
  const mangledNameByNode = new Map<string, string>();
  for (const { modKey, fn } of injectedEntries) {
    if (rootImports.get(fn.name) === modKey) {
      continue;
    }
    if (sourceFnNames.has(fn.name) || claimedInjectedNames.has(fn.name)) {
      const basePrefix = modulePrefixPerModule.get(modKey) ?? sanitizeModuleName(modKey);
      let candidate = `${basePrefix}__${fn.name}`;
      let suffix = 2;
      while (
        sourceFnNames.has(candidate)
        || claimedInjectedNames.has(candidate)
        || anyModuleFunctionOrigin.has(candidate)
      ) {
        candidate = `${basePrefix}_${suffix}__${fn.name}`;
        suffix += 1;
      }
      claimedInjectedNames.add(candidate);
      mangledNameByNode.set(`${modKey}\0${fn.name}`, candidate);
      anyModuleFunctionOrigin.set(candidate, displayNamePerModule.get(modKey) ?? modKey);
    } else {
      claimedInjectedNames.add(fn.name);
    }
  }

  const injected: FunctionDef[] = mangledNameByNode.size === 0
    ? injectedEntries.map(({ fn }) => fn)
    : injectedEntries.map(({ modKey, fn }) => {
      const ownFunctions = functionsPerModule.get(modKey);
      const ownImports = importsPerModule.get(modKey);
      const callRenames = new Map<string, string>();
      for (const [nodeKey, newName] of mangledNameByNode) {
        const sep = nodeKey.indexOf('\0');
        const targetMod = nodeKey.slice(0, sep);
        const origName = nodeKey.slice(sep + 1);
        if (targetMod === modKey && ownFunctions?.has(origName)) {
          callRenames.set(origName, newName);
        } else if (!ownFunctions?.has(origName) && ownImports?.get(origName) === targetMod) {
          callRenames.set(origName, newName);
        }
      }
      const newName = mangledNameByNode.get(`${modKey}\0${fn.name}`) ?? fn.name;
      if (callRenames.size === 0 && newName === fn.name) return fn;
      const newBody = callRenames.size === 0 ? fn.body : rewriteCalls(fn.body, callRenames);
      const newLets = callRenames.size === 0
        ? fn.lets
        : fn.lets.map((binding) => {
          const newValue = rewriteCalls(binding.value, callRenames);
          return newValue === binding.value ? binding : { ...binding, value: newValue };
        });
      return { ...fn, name: newName, body: newBody, lets: newLets };
    });

  // 5. Validate source/module scope boundaries and call-site compatibility.
  const injectedNames = new Set(injected.map((fn) => fn.name));
  const globalFunctions = new Map((ast.functions ?? []).map((fn) => [fn.name, fn]));
  const serviceFunctionNames = new Set((ast.service.functions ?? []).map((fn) => fn.name));
  const unimportedModuleCall = (
    expressions: readonly Expression[],
    sourceFunctions: ReadonlySet<string>,
  ): string | null => expressions.flatMap(collectCalls).find((name) =>
    anyModuleFunctionOrigin.has(name) && !requestedNames.has(name) && !sourceFunctions.has(name)) ?? null;
  const functionExpressions = (functions: readonly FunctionDef[]): Expression[] =>
    functions.flatMap((fn) => [...fn.lets.map(({ value }) => value), fn.body]);
  const globalNames = new Set(globalFunctions.keys());
  let invalidSourceCall = unimportedModuleCall(
    functionExpressions(ast.functions ?? []),
    globalNames,
  );
  const serviceNames = new Set([...globalNames, ...serviceFunctionNames]);
  invalidSourceCall ??= unimportedModuleCall(
    functionExpressions(ast.service.functions ?? []),
    serviceNames,
  );
  const checkMatchCalls = (
    match: typeof ast.service.match,
    inheritedNames: ReadonlySet<string>,
  ): string | null => {
    const names = new Set([...inheritedNames, ...match.functions.map((fn) => fn.name)]);
    const ownExpressions = [
      ...functionExpressions(match.functions),
      ...match.allows.map(({ condition }) => condition),
    ];
    return unimportedModuleCall(ownExpressions, names) ??
      match.children.map((child) => checkMatchCalls(child, names)).find(Boolean) ?? null;
  };
  for (const rootMatch of topLevelMatches(ast.service)) {
    invalidSourceCall ??= checkMatchCalls(rootMatch, serviceNames);
  }
  if (invalidSourceCall) {
    return {
      success: false,
      error: {
        code: 'UNKNOWN_FUNCTION',
        message: `Source calls function '${invalidSourceCall}' from module '${anyModuleFunctionOrigin.get(invalidSourceCall)}' without importing it`,
      },
    };
  }
  const globalCallsServiceScope = (fn: FunctionDef, visiting: ReadonlySet<string>): boolean => {
    if (visiting.has(fn.name)) return false;
    const next = new Set([...visiting, fn.name]);
    const calls = [...fn.lets.flatMap(({ value }) => collectCalls(value)), ...collectCalls(fn.body)];
    return calls.some((call) => {
      const globalFunction = globalFunctions.get(call);
      if (globalFunction) return globalCallsServiceScope(globalFunction, next);
      return injectedNames.has(call) || serviceFunctionNames.has(call);
    });
  };
  const invalidGlobal = [...globalFunctions.values()]
    .find((fn) => globalCallsServiceScope(fn, new Set()));
  if (invalidGlobal) {
    return {
      success: false,
      error: {
        code: 'INCOMPATIBLE_FUNCTION',
        message: `Global function '${invalidGlobal.name}' cannot call a service-scoped function`,
      },
    };
  }

  if (isStorageService || ast.service.name === 'cloud.firestore') {
    let canonicalService: 'cloud.firestore' | 'firebase.storage' = 'cloud.firestore';
    if (isStorageService) {
      canonicalService = 'firebase.storage';
    }
    const reachableFunctions = new Map(injected.map((fn) => [fn.name, fn]));
    for (const fn of injected) {
      const callSites: ModuleCallSite[] = [
        ...moduleCallSites(ast, fn.name, reachableFunctions),
        ...functionCallSites(reachableFunctions, fn.name)
          .map((args) => ({
            arguments: args.map((expression) => ({
              expression,
              provenance: null,
              receiverType: 'unknown' as const,
            })),
          })),
      ];
      let argumentSets: ModuleCallSite[] = [{ arguments: [] }];
      if (callSites.length > 0) {
        argumentSets = callSites;
      }
      for (const { arguments: arguments_ } of argumentSets) {
        const requirement = incompatibleFunction(
          fn,
          canonicalService,
          reachableFunctions,
          arguments_,
        );
        if (requirement) {
          return {
            success: false,
            error: {
              code: 'INCOMPATIBLE_FUNCTION',
              message: `Function '${fn.name}' requires unsupported ${requirement} for service '${ast.service.name}'`,
            },
          };
        }
      }
    }
  }

  // 6. Check for conflicts with top-level (global or service-scope) source-defined functions.
  // Nested match-block functions legally shadow service-scope functions in Rules.
  for (const fn of injected) {
    if (topLevelSourceFnNames.has(fn.name)) {
      return {
        success: false,
        error: {
          code: 'DUPLICATE_FUNCTION',
          message: `Imported function '${fn.name}' conflicts with a function defined in the source`,
        },
      };
    }
  }

  // 7. Inject functions at service scope so service helpers and every match can see them.
  ast.service.functions = [...injected, ...(ast.service.functions ?? [])];
  ast.version = '2';
  ast.imports = [];
  clearExportedModifiers(ast);

  const evidenceIds = new Set<string>();
  let evidencePrefix = 'firestore-rules#';
  if (isStorageService) {
    evidencePrefix = 'storage-rules#';
  }
  for (const moduleName of bundledModulesUsed) {
    const key = conventionalStdlibKey(moduleName) ?? moduleName;
    const moduleEvidence = STDLIB_MODULE_EVIDENCE[
      key as keyof typeof STDLIB_MODULE_EVIDENCE
    ] ?? [];
    for (const evidenceId of moduleEvidence) {
      if (evidenceId.startsWith(evidencePrefix)) evidenceIds.add(evidenceId);
    }
  }

  const assembled = assembleRulesWithSourceMap(ast);
  const sourceMapJson = JSON.stringify(assembled.sourceMap);
  const resolvedWithMap = `${assembled.resolved}// @pyric-source-map: ${sourceMapJson}\n`;
  return {
    success: true,
    data: {
      resolved: resolvedWithMap,
      modules: modulesUsed,
      bundledModules: bundledModulesUsed,
      evidenceIds: [...evidenceIds].sort(),
      sourceMap: assembled.sourceMap,
    },
  };
}

function clearExportedModifiers(ast: FirestoreRules): void {
  const clearBlock = (block: MatchBlock): void => {
    for (const fn of block.functions) fn.exported = false;
    for (const child of block.children) clearBlock(child);
  };
  for (const fn of ast.functions ?? []) fn.exported = false;
  for (const service of allServiceBlocks(ast)) {
    for (const fn of service.functions ?? []) fn.exported = false;
    for (const root of topLevelMatches(service)) clearBlock(root);
  }
}

export function attachAstSourceFile(ast: FirestoreRules, file: string): void {
  const attachToFunction = (fn: {
    loc?: { file?: string };
    returnLoc?: { file?: string };
    body?: { loc?: { file?: string } };
    lets: ReadonlyArray<{ loc?: { file?: string } }>;
  }): void => {
    if (fn.loc !== undefined) fn.loc.file = file;
    for (const binding of fn.lets) {
      if (binding.loc !== undefined) binding.loc.file = file;
    }
    if (fn.returnLoc !== undefined) fn.returnLoc.file = file;
    if (fn.body?.loc !== undefined) fn.body.loc.file = file;
  };
  if (ast.service.loc !== undefined) ast.service.loc.file = file;
  for (const fn of ast.functions ?? []) attachToFunction(fn);
  for (const fn of ast.service.functions ?? []) attachToFunction(fn);
  const stack: MatchBlock[] = [...topLevelMatches(ast.service)];
  while (stack.length > 0) {
    const block = stack.pop();
    if (!block) continue;
    if (block.loc !== undefined) block.loc.file = file;
    for (const allow of block.allows) {
      if (allow.loc !== undefined) allow.loc.file = file;
    }
    for (const fn of block.functions) attachToFunction(fn);
    stack.push(...block.children);
  }
}

export interface AuthoredSourceLoc {
  line: number;
  col: number;
  file: string;
  citation: string;
  expression?: string;
}

/**
 * The source map a resolved ruleset carries on its `// @pyric-source-map:`
 * line, keyed by generated line. The first entry for a line wins. Empty
 * when the source has no source-map line or the line does not parse.
 */
export type AuthoredSourceMap = ReadonlyMap<number, RulesSourceMapEntry>;

const SOURCE_MAP_MARKER = '// @pyric-source-map: ';

/** Read the source map embedded in a resolved rules source. */
export function readAuthoredSourceMap(sourceString: string): AuthoredSourceMap {
  const byLine = new Map<number, RulesSourceMapEntry>();
  const markerIdx = sourceString.indexOf(SOURCE_MAP_MARKER);
  const hasMarker = markerIdx !== -1;
  if (!hasMarker) {
    return byLine;
  }
  const startIdx = markerIdx + SOURCE_MAP_MARKER.length;
  const endIdx = sourceString.indexOf('\n', startIdx);
  let jsonStr = '';
  const hasNewLine = endIdx !== -1;
  if (hasNewLine) {
    jsonStr = sourceString.slice(startIdx, endIdx).trim();
  } else {
    jsonStr = sourceString.slice(startIdx).trim();
  }
  try {
    const sourceMap = JSON.parse(jsonStr) as RulesSourceMapEntry[];
    const isArray = Array.isArray(sourceMap);
    if (isArray) {
      for (const entry of sourceMap) {
        const isFirstForLine = !byLine.has(entry.generatedLine);
        if (isFirstForLine) {
          byLine.set(entry.generatedLine, entry);
        }
      }
    }
  } catch (e) {
    // ignore JSON parse errors
  }
  return byLine;
}

export function resolveAuthoredSourceLoc(
  sourceString: string,
  generatedLine?: number,
  generatedCol?: number,
  fallbackFile?: string,
  fallbackExpression?: string,
): AuthoredSourceLoc | undefined {
  const isLineUndefined = generatedLine === undefined;
  if (isLineUndefined) {
    return undefined;
  }
  return resolveAuthoredLoc(
    readAuthoredSourceMap(sourceString),
    generatedLine,
    generatedCol,
    fallbackFile,
    fallbackExpression,
  );
}

/** {@link resolveAuthoredSourceLoc} against a source map read once. */
export function resolveAuthoredLoc(
  sourceMap: AuthoredSourceMap,
  generatedLine?: number,
  generatedCol?: number,
  fallbackFile?: string,
  fallbackExpression?: string,
): AuthoredSourceLoc | undefined {
  const isLineUndefined = generatedLine === undefined;
  if (isLineUndefined) {
    return undefined;
  }
  let line = generatedLine!;
  let col = 1;
  const isColDefined = generatedCol !== undefined;
  if (isColDefined) {
    col = generatedCol!;
  }
  let file = 'firestore.rules';
  const isFallbackDefined = fallbackFile !== undefined;
  if (isFallbackDefined) {
    const isNotEmpty = fallbackFile !== '';
    if (isNotEmpty) {
      file = fallbackFile!;
    }
  }
  let expression: string | undefined = undefined;
  const isExprDefined = fallbackExpression !== undefined;
  if (isExprDefined) {
    expression = fallbackExpression;
  }

  const entry = sourceMap.get(line);
  const hasEntry = entry !== undefined;
  if (hasEntry) {
    line = entry!.authoredLine;
    col = entry!.authoredCol;
    file = entry!.authoredFile;
    const hasEntryExpr = entry!.expression !== undefined;
    if (hasEntryExpr) {
      expression = entry!.expression;
    }
  }

  const citation = `${file}:${line}:${col}`;
  const result: AuthoredSourceLoc = { line, col, file, citation };
  const hasFinalExpr = expression !== undefined;
  if (hasFinalExpr) {
    result.expression = expression;
  }
  return result;
}
