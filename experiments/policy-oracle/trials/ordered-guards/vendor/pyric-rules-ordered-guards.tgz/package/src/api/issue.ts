/**
 * The unified rules diagnostic -- one shape for every issue a ruleset can
 * carry, whatever stage produced it.
 *
 * Before this, three separate shapes described the same idea: the linter's
 * `LintWarning`, the validator's `ValidationFinding`, and the parser's
 * `ParseError`. A caller that wanted "everything wrong with this source"
 * had to collect three arrays and reconcile three different field sets.
 * `RuleIssue` collapses them. The `origin` field records which stage found
 * the issue so a caller can still filter (`origin === 'parse'` for the
 * compile blockers) without three types.
 */

import type { ParseError } from '../grammar/FirestoreParser.js';
import type { LintWarning } from '../linter/linter.js';
import type { ValidationFinding } from '../grammar/FirestoreValidator.js';
import type { RtdbRulesFinding } from '../rtdb/constraints/document.js';
import type { RtdbSecurityFinding } from '../rtdb/grammar/ruleset-lint.js';
import type { CompileLimitViolation } from '../grammar/compile-limits.js';

/** Ordered by decreasing urgency. `info` is advisory. */
export type RuleIssueSeverity = 'error' | 'warning' | 'info';

/**
 * The stage that produced the issue.
 *   - `parse`    -- the source did not parse, or broke a production compile
 *                   limit; nothing downstream ran.
 *   - `validate` -- a structural/security finding on a parsed ruleset.
 *   - `lint`     -- a budget/quality/hallucination warning.
 */
export type RuleIssueOrigin = 'parse' | 'validate' | 'lint';

export interface RuleIssue {
  /** Stable machine code, e.g. `'PARSE_ERROR'`, `'SEC-4'`, `'GET_BUDGET'`. */
  code: string;
  severity: RuleIssueSeverity;
  /** Human-readable description. */
  message: string;
  /** Rules path the issue applies to, when known (e.g. `'/users/{uid}'`). */
  path?: string;
  /** The Realtime Database rule at `path` the issue applies to. Absent for
   *  Firestore issues and for an RTDB issue about the whole ruleset. */
  rule?: '.read' | '.write' | '.validate';
  /** 1-indexed source line, when known. */
  line?: number;
  /** The Realtime Database rules file the issue is in, as `firebase.json`
   *  names it, for a ruleset read with `rtdbRules.fromFirebaseJson`. */
  file?: string;
  /** Suggested remediation, verbatim, when the producing stage offers one. */
  fix?: string;
  origin: RuleIssueOrigin;
}

export function parseErrorToIssue(error: ParseError): RuleIssue {
  const issue: RuleIssue = {
    code: 'PARSE_ERROR',
    severity: 'error',
    message: error.message,
    origin: 'parse',
  };
  if (error.line > 0) issue.line = error.line;
  return issue;
}

/** A compile-limit rejection blocks the ruleset the way a parse failure does, so it carries origin 'parse'. */
export function compileLimitViolationToIssue(violation: CompileLimitViolation): RuleIssue {
  const issue: RuleIssue = {
    code: violation.code,
    severity: 'error',
    message: violation.message,
    origin: 'parse',
  };
  if (violation.line !== undefined) issue.line = violation.line;
  return issue;
}

const COMPILE_LIMIT_LINT_CODES: ReadonlySet<string> = new Set([
  'SOURCE_SIZE',
  'LET_LIMIT',
  'NESTING_DEPTH',
  'SLASH_STARTS_PATH',
  'GLOB_MATCH_COUNT',
  'CALL_DEPTH',
  'UNSUPPORTED_RULES_VERSION',
  'UNRESOLVED_MODULES',
  'INVALID_REGEX_PATTERN',
  'INVALID_NUMBER_LITERAL',
  'DOUBLE_MINUS',
  'FUNCTION_REDEFINED',
  'VARIABLE_REDEFINED',
  'DUPLICATE_SERVICE',
  'NOT_MODULE_SOURCE',
  'PARSE_FAILED',
  'UNKNOWN_MODULE',
  'UNSUPPORTED_SERVICE',
  'DUPLICATE_FUNCTION',
  'UNKNOWN_FUNCTION',
  'INCOMPATIBLE_FUNCTION',
  'CIRCULAR_DEPENDENCY',
]);

export function lintWarningToIssue(warning: LintWarning): RuleIssue {
  const isCompileLimit =
    warning.severity === 'error' && COMPILE_LIMIT_LINT_CODES.has(warning.rule);
  const issue: RuleIssue = {
    code: warning.rule,
    severity: warning.severity,
    message: warning.message,
    origin: isCompileLimit ? 'parse' : 'lint',
  };
  if (warning.location?.matchPath) issue.path = warning.location.matchPath;
  if (warning.location?.line !== undefined) issue.line = warning.location.line;
  if (warning.fix) issue.fix = warning.fix;
  return issue;
}

/** Validator severities are a four-level urgency scale; fold them onto the
 *  three-level `RuleIssue` scale (critical/high -> error, medium -> warning,
 *  low -> info) so one list sorts sensibly. */
export function validationFindingToIssue(finding: ValidationFinding): RuleIssue {
  const severity: RuleIssueSeverity =
    finding.severity === 'critical' || finding.severity === 'high'
      ? 'error'
      : finding.severity === 'medium'
        ? 'warning'
        : 'info';
  return {
    code: finding.code,
    severity,
    message: finding.message,
    path: finding.path,
    origin: 'validate',
  };
}

/** An RTDB security finding is a validator finding on one rule, with a fix. */
export function rtdbSecurityFindingToIssue(finding: RtdbSecurityFinding): RuleIssue {
  return {
    ...validationFindingToIssue(finding),
    rule: finding.rule,
    fix: finding.fix,
  };
}

/** Codes on RTDB check errors that mean the source never reached validation:
 *  an expression that does not parse, or a ruleset that does not compile. */
const RTDB_PARSE_CODES = new Set(['PARSE_ERROR', 'COMPILE_ERROR']);

/** Map an RTDB check finding (from the internal document `check()`) onto the
 *  unified issue. `severity` is decided by the caller: check errors come from
 *  the parser, the ruleset compiler, or the validator, and check warnings come
 *  only from the linter. */
export function rtdbFindingToIssue(
  finding: RtdbRulesFinding,
  severity: 'error' | 'warning',
): RuleIssue {
  const origin: RuleIssueOrigin =
    severity === 'warning'
      ? 'lint'
      : RTDB_PARSE_CODES.has(finding.code)
        ? 'parse'
        : 'validate';
  const issue: RuleIssue = {
    code: finding.code,
    severity,
    message: finding.message,
    path: finding.path,
    origin,
  };
  if (finding.rule !== 'ruleset') issue.rule = finding.rule;
  return issue;
}
