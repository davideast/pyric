/**
 * The assertion adapter layer — the bridge from the data-returning front
 * door to a throwing test runner.
 *
 * `simulate` never throws; a runner needs failures to throw. `assertCase`
 * is that seam, and the ONLY throwing verb beyond the constructors:
 *   - `assertCase(result)` throws on a failed or abstained result.
 *   - `assertCase(rulesetOrSource, oneCase)` simulates that single case and
 *     throws on a miss — runner wiring is
 *     `for (const c of cases) test(c.description, () => assertCase(ruleset, c))`.
 *   - `explainCase(result)` renders the single sanctioned trace string —
 *     used verbatim as the thrown error's message, so a runner surfaces the
 *     "why" for free.
 */

import { firestoreRules } from './firestore.js';
import type { FirestoreRuleset } from './firestore.js';
import type { RtdbRuleset } from './rtdb.js';
import type { StorageRuleset } from './storage.js';
import { RulesAssertionError, RulesUnsupportedError } from './errors.js';
import { safeReadProp } from '../test/case-refusals.js';
import type { RuleEvaluation } from '../test/spec.js';
import type {
  FirestoreCase,
  CaseResult,
  RtdbCase,
  RtdbCaseResult,
  RtdbRuleEvaluation,
  StorageCase,
  StorageCaseResult,
} from './case-types.js';

type AnyCaseResult = CaseResult | RtdbCaseResult | StorageCaseResult;

function isRtdbResult(r: AnyCaseResult): r is RtdbCaseResult {
  return 'matchedRule' in r;
}

function isStorageResult(r: AnyCaseResult): r is StorageCaseResult {
  return 'service' in r && r.service === 'storage';
}

// ─── Trace rendering ─────────────────────────────────────────────────

function renderRuleEvaluation(entry: RuleEvaluation): string {
  const ops = entry.operations.join(',');
  const loc = entry.line !== undefined ? ` (line ${entry.line})` : '';
  const block = entry.matchPath ? ` [${entry.matchPath}]` : '';
  const cond = entry.conditionText ? `: ${entry.conditionText}` : '';
  const msg = entry.message ? ` (${entry.message})` : '';
  return `    #${entry.ruleIndex} (${ops})${block}${loc} -> ${entry.verdict}${cond}${msg}`;
}

function safeCaseString(caseValue: unknown, key: string, fallback = '<unknown>'): string {
  const raw = safeReadProp(caseValue, key);
  return typeof raw === 'string' ? raw : fallback;
}

function renderFirestore(r: CaseResult): string {
  const status = r.unsupported ? 'UNSUPPORTED' : r.passed ? 'PASS' : 'FAIL';
  const method = safeCaseString(r.case, 'method');
  const path = safeCaseString(r.case, 'path', '');
  const lines: string[] = [
    `${status}: ${r.description}`,
    `  ${method} ${path} (expected ${r.expectation}, got ${r.decision})`,
  ];
  if (r.queryProof) {
    const detail = r.queryProof.reason ? ` (${r.queryProof.reason})` : '';
    lines.push(`  query proof: ${r.queryProof.verdict}${detail}`);
    if (r.queryProof.remediation) {
      lines.push(`  remediation: ${r.queryProof.remediation}`);
    }
  }
  if (r.trace.length > 0) {
    lines.push('  rules evaluated:');
    for (const entry of r.trace) lines.push(renderRuleEvaluation(entry));
  }
  if (r.pathResolution && r.pathResolution.attempts.length > 0) {
    const misses = r.pathResolution.attempts.filter((a) => !a.matched);
    if (misses.length > 0) {
      lines.push('  path near-misses:');
      for (const a of misses) {
        lines.push(
          `    ${a.blockPath} (${a.matchedSegments}/${a.totalSegments} segments${a.reason ? `, ${a.reason}` : ''})`,
        );
      }
    }
  }
  for (const note of r.notes) lines.push(`  note: ${note}`);
  return lines.join('\n');
}

function renderRtdbRuleEvaluation(entry: RtdbRuleEvaluation): string {
  const bindings = Object.entries(entry.pathVariableBindings)
    .map(([name, value]) => `${name} = ${value}`)
    .join(', ');
  const bound = bindings === '' ? '' : ` (${bindings})`;
  const msg = entry.message ? ` (${entry.message})` : '';
  return `    ${entry.path} .${entry.kind} -> ${entry.verdict}: ${entry.conditionText}${bound}${msg}`;
}

function renderRtdb(r: RtdbCaseResult): string {
  const status = r.unsupported ? 'UNSUPPORTED' : r.passed ? 'PASS' : 'FAIL';
  const operation = safeCaseString(r.case, 'operation');
  const path = safeCaseString(r.case, 'path', '');
  const name = r.description ?? `${operation} ${path}`;
  const lines: string[] = [
    `${status}: ${name}`,
    `  ${operation} ${path}${r.instance === undefined ? '' : ` on ${r.instance}`} (expected ${r.expectation}, got ${r.decision})`,
    `  matched ${r.matchedRule} @ ${r.matchedPath}`,
    `  reason: ${r.reason}`,
  ];
  if (r.trace.length > 0) {
    lines.push('  rules evaluated:');
    for (const entry of r.trace) lines.push(renderRtdbRuleEvaluation(entry));
  }
  return lines.join('\n');
}

function renderStorage(r: StorageCaseResult): string {
  const status = r.unsupported ? 'UNSUPPORTED' : r.passed ? 'PASS' : 'FAIL';
  const method = safeCaseString(r.case, 'method');
  const path = safeCaseString(r.case, 'path', '');
  const bucket = r.bucket === undefined ? '' : ` in ${r.bucket}`;
  const lines: string[] = [
    `${status}: ${r.description}`,
    `  ${method} ${path}${bucket} (expected ${r.expectation}, got ${r.decision})`,
  ];
  if (r.decidingRule !== undefined) {
    const line = r.decidingRule.line === undefined ? '' : ` (line ${r.decidingRule.line})`;
    lines.push(`  deciding rule: ${r.decidingRule.path}${line}`);
  }
  for (const reason of r.reasons) lines.push(`  reason: ${reason}`);
  return lines.join('\n');
}

/**
 * Render a case result as a human-readable trace. The single sanctioned
 * trace renderer — used as the message of the error `assertCase` throws, and
 * available directly for logging a result without asserting.
 */
export function explainCase(result: AnyCaseResult): string {
  if (isRtdbResult(result)) return renderRtdb(result);
  if (isStorageResult(result)) return renderStorage(result);
  return renderFirestore(result);
}

// ─── assertCase ──────────────────────────────────────────────────────

function assertResult(result: AnyCaseResult): void {
  if (result.unsupported) {
    throw new RulesUnsupportedError(explainCase(result));
  }
  if (!result.passed) {
    throw new RulesAssertionError(explainCase(result));
  }
}

/**
 * Throw when a case result did not pass. A simulator abstention throws
 * {@link RulesUnsupportedError}; a genuine expectation mismatch throws
 * {@link RulesAssertionError}. Both carry the {@link explainCase} trace as
 * their message. Returns `void` on a passing result.
 */
export function assertCase(result: AnyCaseResult): void;
/**
 * Simulate one case against a ruleset and throw on a miss — the runner
 * form: `for (const c of cases) test(c.description, () => assertCase(ruleset, c))`.
 */
export function assertCase(ruleset: FirestoreRuleset, oneCase: FirestoreCase): void;
export function assertCase(ruleset: RtdbRuleset, oneCase: RtdbCase): void;
export function assertCase(ruleset: StorageRuleset, oneCase: StorageCase): void;
/** Convenience: compile Firestore source and assert one case against it. */
export function assertCase(source: string, oneCase: FirestoreCase): void;
export function assertCase(
  first: AnyCaseResult | FirestoreRuleset | RtdbRuleset | StorageRuleset | string,
  oneCase?: FirestoreCase | RtdbCase | StorageCase,
): void {
  if (oneCase === undefined) {
    assertResult(first as AnyCaseResult);
    return;
  }
  const ruleset: FirestoreRuleset | RtdbRuleset | StorageRuleset =
    typeof first === 'string'
      ? firestoreRules(first)
      : (first as FirestoreRuleset | RtdbRuleset | StorageRuleset);
  // `simulate` on either ruleset accepts a one-element array of the matching
  // case type and returns one result.
  const summary = (ruleset as FirestoreRuleset).simulate([oneCase as FirestoreCase]);
  assertResult(summary.cases[0]);
}
