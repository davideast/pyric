// AUTO-GENERATED -- do not edit by hand. Regenerate via:
//   bun run inline-grammar (packages/rules)
// Source: RtdbExpr.ohm

export const RTDB_EXPR_OHM_SOURCE = `RtdbExpr {
  Expr = Ternary

  Ternary
    = LogicalOr "?" Ternary ":" Ternary  -- ternary
    | LogicalOr

  // \`||\` and \`&&\` match as flat chains, not left recursion, so a semantics
  // folds a chain of any length in a loop instead of descending once per
  // term. Production deploys a 2,000-term \`||\` chain (r51).
  LogicalOr
    = LogicalAnd ("||" LogicalAnd)+  -- or
    | LogicalAnd

  LogicalAnd
    = Equality ("&&" Equality)+  -- and
    | Equality

  Equality
    = Equality "===" Comparison  -- strictEq
    | Equality "!==" Comparison  -- strictNeq
    | Equality "==" Comparison   -- looseEq
    | Equality "!=" Comparison   -- looseNeq
    | Comparison

  Comparison
    = Comparison ">=" Additive   -- gte
    | Comparison "<=" Additive   -- lte
    | Comparison ">" Additive    -- gt
    | Comparison "<" Additive    -- lt
    | Additive

  Additive
    = Additive "+" Multiplicative  -- add
    | Additive "-" Multiplicative  -- sub
    | Multiplicative

  Multiplicative
    = Multiplicative "*" UnaryExpr  -- mul
    | Multiplicative "/" UnaryExpr  -- div
    | Multiplicative "%" UnaryExpr  -- mod
    | UnaryExpr

  UnaryExpr
    = "!" UnaryExpr  -- not
    | "-" UnaryExpr  -- neg
    | CallExpr

  CallExpr
    = CallExpr "." ident "(" ListOf<Expr, ","> ")"  -- methodCall
    | CallExpr "." ident                             -- memberAccess
    | CallExpr "[" Expr "]"                          -- indexAccess
    | Primary

  Primary
    = "(" Expr ")"  -- paren
    | Array
    | literal
    | ident

  Array = "[" ListOf<Expr, ","> "]"

  literal
    = number
    | string
    | regex
    | bool
    | null

  number
    = digit+ "." digit+ exponent?  -- float
    | digit+ exponent              -- exp
    | digit+                       -- int

  exponent = ("e" | "E") ("+" | "-")? digit+

  string
    = "\\"" doubleStringChar* "\\""  -- double
    | "'" singleStringChar* "'"    -- single

  doubleStringChar
    = "\\\\" any  -- escape
    | ~"\\"" any -- char

  singleStringChar
    = "\\\\" any  -- escape
    | ~"'" any  -- char

  regex = "/" regexBody "/" regexFlags

  regexBody = regexChar+

  regexChar
    = "\\\\" any     -- escape
    | regexClass   -- class
    | ~("/" | "\\n" | "[") any  -- char

  regexClass = "[" regexClassBody "]"

  regexClassBody
    = "^"? "]" regexClassChar* &"]"  -- leadingClose
    | regexClassChar*                -- normal

  regexClassChar
    = "\\\\" any     -- escape
    | ~("]" | "\\n") any  -- char

  regexFlags = alnum*

  bool
    = "true" ~identChar   -- true
    | "false" ~identChar  -- false

  null = "null" ~identChar

  ident = "$"? identStart identChar*

  identStart = letter | "_"

  identChar = alnum | "_" | "$"
}
`;
