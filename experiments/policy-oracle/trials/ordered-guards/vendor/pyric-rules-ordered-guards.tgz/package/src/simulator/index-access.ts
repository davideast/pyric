/**
 * Index access `value[index]` and dot access `value.name`, shared by the
 * Firestore simulator and the Storage evaluator.
 *
 * Production reads a map key with the same check as dot access: a key the
 * map does not own is an error ("Property k is undefined on object."), never
 * null, so `data['k'] == null` and `data['k'] != true` deny on a map without
 * `k`. A key present with a null value reads as null. A list index must be an
 * int within `[0, size)`; any other int is an out-of-bound error and any other
 * index type is an unsupported operation. Firestore and Storage report the
 * same verdict and text for every shape (corpus scenarios
 * `undefined-field-access`, `metadata-access` and
 * `list-map-literals-and-slice`). Each evaluator turns an
 * `IndexAccessFailure` into its own error value, so `&&`/`||` absorb it.
 */
import { describeRulesType, isRulesMap } from './rules-type.js';
import { sliceBoundsError } from './slice-bounds.js';
import { RulesValue } from './wrappers/base.js';
import { rulesInt } from './rules-int.js';

/** Production's error for a failed index or key read. */
export class IndexAccessFailure {
  constructor(readonly message: string) {}
}

/** Production's error text for reading a key a map does not own. */
export function undefinedPropertyMessage(name: string): string {
  return `Property ${name} is undefined on object.`;
}

/** Production's error text for a list or string index outside `[0, size)`. */
export function indexOutOfBoundMessage(index: bigint | number, size: number): string {
  return `Index out of bound error. Index: [${index}] , size: [${size}].`;
}

/** `list[index]`: the element, or production's error for the index. */
export function indexList(list: readonly unknown[], index: unknown): unknown {
  const int = rulesInt(index);
  if (int === undefined) {
    return new IndexAccessFailure(
      `Unsupported operation error. Received: list[${describeRulesType(index)}]. Expected: list[int].`,
    );
  }
  if (int < 0n || int >= list.length) {
    return new IndexAccessFailure(indexOutOfBoundMessage(int, list.length));
  }
  return list[Number(int)];
}

/** `map[key]`: the value of an own key, or production's error for a key the map does not own. */
export function indexMap(map: object, key: string): unknown {
  if (!Object.hasOwn(map, key)) return new IndexAccessFailure(undefinedPropertyMessage(key));
  const value = (map as Record<string, unknown>)[key];
  return value === undefined ? new IndexAccessFailure(undefinedPropertyMessage(key)) : value;
}

/** `string[index]`: the character at an int index, or production's error for the index. */
export function indexString(value: string, index: unknown): unknown {
  const int = rulesInt(index);
  if (int === undefined) {
    return new IndexAccessFailure(
      `Unsupported operation error. Received: string[${describeRulesType(index)}]. Expected: string[int].`,
    );
  }
  if (int < 0n || int >= value.length) {
    return new IndexAccessFailure(indexOutOfBoundMessage(int, value.length));
  }
  return value[Number(int)];
}

/** A path value as index access reads it: its segments and the names bound to them. */
export interface IndexablePath {
  readonly segments: readonly string[];
  readonly bindings: Readonly<Record<string, string>>;
}

function isPath(value: unknown): value is RulesValue & IndexablePath {
  return (
    value instanceof RulesValue &&
    (value.typeName === 'path' || value.typeName === 'reference') &&
    Array.isArray((value as Partial<IndexablePath>).segments)
  );
}

/** Production's error for indexing a value that has no index operator, such as a duration. */
export const NO_INDEX_OPERATOR_MESSAGE = 'Function not found error: Name: [[]].';

/**
 * `value[index]` on any value, as production reads it: a list or a string by
 * int index, a map by string key, a path by int segment index or string bound
 * name (`request.path[0]` is the first segment; an unbound name is an error,
 * not null). Non-string keys on maps and non-int/non-string keys on paths are
 * unsupported operation errors rather than JS string coercions. A wrapper value
 * other than a path has no index operator (corpus scenarios
 * `undefined-field-access` and `list-map-literals-and-slice`).
 */
export function indexValue(value: unknown, index: unknown): unknown {
  if (Array.isArray(value)) return indexList(value, index);
  if (typeof value === 'string') return indexString(value, index);
  if (isPath(value)) {
    const int = rulesInt(index);
    if (int !== undefined) {
      if (int >= 0n && int < value.segments.length) {
        return value.segments[Number(int)];
      }
      return new IndexAccessFailure(indexOutOfBoundMessage(int, value.segments.length));
    }
    if (typeof index !== 'string') {
      return new IndexAccessFailure(
        `Unsupported operation error. Received: path[${describeRulesType(index)}]. Expected: path[int], path[string].`,
      );
    }
    if (Object.hasOwn(value.bindings, index)) {
      return value.bindings[index];
    }
    return new IndexAccessFailure(undefinedPropertyMessage(index));
  }
  if (!isRulesMap(value)) return new IndexAccessFailure(NO_INDEX_OPERATOR_MESSAGE);
  if (typeof index !== 'string') {
    return new IndexAccessFailure(
      `Unsupported operation error. Received: map[${describeRulesType(index)}]. Expected: map[string].`,
    );
  }
  return indexMap(value, index);
}

/**
 * `value.name` on a map or a path, as production reads it: a map's own key,
 * a path's bound name, or production's error. An unbound name on a path is
 * the same error the bracket form gives (`request.path.segments` and
 * `request.path['segments']` both fail with "Property segments is undefined
 * on object.", corpus scenarios `undefined-field-access` and
 * `list-map-literals-and-slice`), never null. Dot access reads maps and
 * paths only, so on a list, string, number or bool it is a type error:
 * `list.length` and `'abc'.length` are errors, never the JavaScript
 * property. Other wrapper values dispatch their own fields before this.
 */
export function readMember(value: unknown, name: string): unknown {
  if (isRulesMap(value)) return indexMap(value, name);
  if (isPath(value)) return indexValue(value, name);
  return new IndexAccessFailure(`Type error. Received: [${describeRulesType(value)}] Expected: [map,path].`);
}

/** Range slice `obj[start:end]` on a List or String; errors on null/non-sliceable or bad bounds. */
export function sliceValue(obj: unknown, start: unknown, end: unknown): unknown {
  const from = rulesInt(start);
  if (from === undefined) {
    return new IndexAccessFailure(`Slice start must be an integer, got ${describeRulesType(start)}`);
  }
  const to = rulesInt(end);
  if (to === undefined) {
    return new IndexAccessFailure(`Slice end must be an integer, got ${describeRulesType(end)}`);
  }
  if (typeof obj === 'string' || Array.isArray(obj)) {
    const boundsError = sliceBoundsError(from, to, obj.length);
    if (boundsError) return new IndexAccessFailure(boundsError);
    return obj.slice(Number(from), Number(to));
  }
  return new IndexAccessFailure(`Slice not supported on ${describeRulesType(obj)}`);
}
