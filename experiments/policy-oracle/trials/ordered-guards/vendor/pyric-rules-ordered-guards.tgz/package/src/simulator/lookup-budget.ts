import type { SimulationContext } from './evaluation-context.js';
import { ResourceLimitError } from './eval-error.js';
import {
  isDocumentPath,
  isMalformedDatabaseLookupPath,
  nonDefaultDatabaseInLookupPath,
  normalizeDocumentPath,
} from './document-lookups.js';

// ═══ Per-request document-lookup budget ═══
//
// Production hard-limits security-rule document access calls, get(),
// exists(), getAfter() and existsAfter(), to 10 per single-document request
// or query evaluation. Multi-document transactions and batched writes get
// an AGGREGATE budget of 20 on top of a per-operation 10; only the per-
// operation 10 is modeled here (each batched op's simulate() call gets its
// own fresh LookupBudget, mirroring how WriteRuntime.buildBatchProjection
// shares one projection map across per-op simulate() calls but each op is
// its own rules evaluation).
//
// Counting semantics: distinct accesses, not raw calls. In-repo production
// evidence:
//   - site-docs secure/firestore-rules-limits.md ("More than 10 document
//     access calls"): "Repeated reads of the same path are cached; reads of
//     different paths are not."
//   - rules/stdlib-modules.ts spaces guidance: "get() is cached per request,
//     so all rules on the request share a single read of the 10-get budget."
//   - The Storage sibling limit (storage/rules-methods.ts) uses a
//     per-request distinct-path set, verified by real-resource capture.
//
// What is implemented, exactly: the budget keys on (kind, path), where kind
// is 'doc' for pre-write reads (get/exists) and 'after' for post-write
// projections (getAfter/existsAfter). So get() and exists() on one path
// share a slot, getAfter() and existsAfter() on one path share a slot, and
// a path read by BOTH a pre-write and a post-write call charges TWO slots.
// The two calls read different snapshots, so charging them separately is the
// fail-closed direction while production's cache granularity is uncaptured.
//
// TODO(unverified): a credentialed production capture is needed to pin
// (a) whether get() and exists() on one path really share one cache slot,
// (b) whether getAfter() on a path already read by get() charges a second
// slot or reuses the first, and (c) whether exhausting the budget is
// absorbable by a determining CEL operand (modeled: not absorbable). The
// capture is a ruleset whose condition performs 10 lookups and then an
// 11th, deployed and probed against a live project. The Rules Test API does
// not enforce the budget, so it cannot produce this evidence.

/** Production's per-evaluation document access budget (single request). */
export const DOCUMENT_LOOKUP_LIMIT = 10;

/** Production's aggregate document access budget across a multi-document batch or transaction. */
export const MULTI_DOCUMENT_LOOKUP_LIMIT = 20;

const LOOKUP_COLLECTOR_KEY = Symbol.for('pyric.firestore.lookupCollector');
const batchBudgets = new WeakMap<object, LookupBudget>();

function getBatchLookupBudget(batchProjection: object): LookupBudget {
  const existingBudget = batchBudgets.get(batchProjection);
  if (existingBudget !== undefined) {
    return existingBudget;
  }
  const budget = new LookupBudget(MULTI_DOCUMENT_LOOKUP_LIMIT);
  batchBudgets.set(batchProjection, budget);
  return budget;
}

/**
 * Budget exhaustion. A {@link ResourceLimitError}, not a plain EvalError,
 * because it fails the WHOLE request closed: CEL error absorption
 * (`error || true`, `error && false`) must not swallow it into an ALLOW,
 * and a sibling allow rule or match block must not evaluate past it.
 */
export class LookupBudgetError extends ResourceLimitError {
  constructor(message: string) {
    super(message);
    this.name = 'LookupBudgetError';
  }
}

const MAX_LOOKUP_FRONTIERS = 64;

function isSubsetOf(smaller: ReadonlySet<string>, larger: ReadonlySet<string>): boolean {
  if (smaller.size > larger.size) return false;
  for (const key of smaller) {
    if (!larger.has(key)) return false;
  }
  return true;
}

function throwLookupLimitExceeded(limit: number): never {
  const isSingleRequestLimit = limit === DOCUMENT_LOOKUP_LIMIT;
  let scopeDescription = `multi-document batch/transaction (${limit} allowed across the atomic operation)`;
  if (isSingleRequestLimit) {
    scopeDescription = 'request (production allows 10 per request; the 11th distinct access fails the evaluation)';
  }
  throw new LookupBudgetError(
    `document access limit exceeded: already read ${limit} distinct documents `
    + `via get()/exists()/getAfter()/existsAfter() in this ${scopeDescription}`,
  );
}

function pruneLookupFrontiers(sets: Set<string>[], limit: number): Set<string>[] {
  if (sets.length <= 1) return sets.length === 0 ? [new Set()] : sets;
  // Sort largest-first so superset checks reject dominated subsets quickly.
  sets.sort((a, b) => b.size - a.size);
  const maximal: Set<string>[] = [];
  for (const candidate of sets) {
    if (maximal.some((existing) => isSubsetOf(candidate, existing))) {
      continue;
    }
    maximal.push(candidate);
  }
  if (maximal.length <= MAX_LOOKUP_FRONTIERS) {
    return maximal;
  }
  const kept = maximal.slice(0, MAX_LOOKUP_FRONTIERS);
  for (let i = MAX_LOOKUP_FRONTIERS; i < maximal.length; i++) {
    const extra = maximal[i]!;
    let bestIdx = 0;
    let bestMerged = new Set([...kept[0]!, ...extra]);
    for (let j = 1; j < kept.length; j++) {
      const candidateMerged = new Set([...kept[j]!, ...extra]);
      if (candidateMerged.size < bestMerged.size) {
        bestMerged = candidateMerged;
        bestIdx = j;
      }
    }
    if (bestMerged.size > limit) {
      throwLookupLimitExceeded(limit);
    }
    kept[bestIdx] = bestMerged;
  }
  return kept;
}

/**
 * Per-request lookup counter. The handler creates ONE per test case
 * (request evaluation) and every match block and allow rule evaluated for
 * that request shares it: production's budget spans OR'd rules and
 * overlapping match blocks alike (the linter's SHARED_GATE "cross-rule
 * budget exhaustion" hazard).
 */
export class LookupBudget {
  private frontiers: Set<string>[] = [new Set()];

  constructor(private readonly limit: number = DOCUMENT_LOOKUP_LIMIT) {}

  /**
   * Charge one document access. `kind` is 'doc' for pre-write reads
   * (get/exists) and 'after' for post-write projections (getAfter/
   * existsAfter). A repeat access to the same (kind, path) is cached and
   * free; the 11th DISTINCT access (or 21st across a batch/transaction)
   * throws {@link LookupBudgetError}, which fails the request closed.
   */
  charge(kind: 'doc' | 'after', normalizedPath: string): void {
    const key = `${kind}:${normalizedPath}`;
    for (const accessed of this.frontiers) {
      if (accessed.has(key)) continue; // cached on this execution frontier
      if (accessed.size >= this.limit) {
        throwLookupLimitExceeded(this.limit);
      }
      accessed.add(key);
    }
  }

  /** Clone active accessed-path frontiers for a mutually exclusive branch or query variant. */
  fork(): LookupBudget {
    const child = new LookupBudget(this.limit);
    child.frontiers = this.frontiers.map((s) => new Set(s));
    return child;
  }

  /** Merge mutually exclusive forked budgets, pruning dominated subsets losslessly. */
  mergeForks(branches: readonly LookupBudget[]): void {
    if (branches.length === 0) return;
    const combined: Set<string>[] = [];
    for (const branch of branches) {
      for (const s of branch.frontiers) {
        combined.push(new Set(s));
      }
    }
    this.frontiers = pruneLookupFrontiers(combined, this.limit);
  }
}

/**
 * The single charging seam for all four document access builtins. Charges
 * the budget for a raw (unnormalized) lookup path. Malformed paths charge
 * nothing: no document read happens, and the caller's own validation
 * produces the error or false result.
 */
export function chargeLookup(ctx: SimulationContext, kind: 'doc' | 'after', rawPath: string): void {
  if (!ctx.lookupBudget) return;
  if (isMalformedDatabaseLookupPath(rawPath, ctx.database)) return;
  if (nonDefaultDatabaseInLookupPath(rawPath, ctx.database) !== undefined) return;
  const normalized = normalizeDocumentPath(rawPath, ctx.database);
  if (!isDocumentPath(normalized)) return;
  const isPreWriteLookup = kind === 'doc';
  if (isPreWriteLookup) {
    const collector = (globalThis as { [LOOKUP_COLLECTOR_KEY]?: Set<string> })[LOOKUP_COLLECTOR_KEY];
    const hasCollector = collector !== undefined;
    if (hasCollector) {
      collector.add(normalized);
    }
  }
  ctx.lookupBudget.charge(kind, normalized);
  const batchProjection = ctx.batchProjection;
  const hasBatchProjection = batchProjection !== undefined;
  if (hasBatchProjection) {
    getBatchLookupBudget(batchProjection).charge(kind, normalized);
  }
}
