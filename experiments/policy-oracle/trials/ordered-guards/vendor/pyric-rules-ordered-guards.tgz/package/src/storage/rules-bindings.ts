import { Timestamp } from '../simulator/wrappers/timestamp.js';
import { parseStrictIsoMillis } from '../test/case-refusals.js';
import type { EvaluationInput, StorageResource } from './rules.js';
import { RuleError } from './rules-values.js';
import { StoragePath } from './rules-path.js';
import { normalizeAuthState } from '../auth/auth-state.js';
import { typeClaimNumbers } from '../simulator/rules-int.js';

/**
 * Build the `resource.*` binding from the existing-object record, converting
 * the ISO-8601 time fields to timestamps so they compare against
 * `request.time` (which {@link buildRequestObject} models the same way),
 * against each other (`resource.timeCreated == resource.updated`), and take
 * durations (`resource.timeCreated + duration.value(1, 'h')`).
 *
 * A field the record does not carry is left `undefined`, which the
 * evaluator's property read reports as production's absent-property ERROR.
 */
function omitUndefined<T extends Record<string, unknown>>(obj: T): T {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined) {
      Object.defineProperty(out, k, {
        value: v,
        enumerable: true,
        configurable: true,
        writable: true,
      });
    }
  }
  return out as T;
}

export function buildResourceObject(resource: StorageResource): Record<string, unknown> {
  return omitUndefined({
    size: resource.size,
    contentType: resource.contentType,
    metadata: resource.metadata,
    name: resource.name,
    bucket: resource.bucket,
    generation: resource.generation,
    metageneration: resource.metageneration,
    timeCreated: isoToTimestamp(resource.timeCreated),
    updated: isoToTimestamp(resource.updated),
    md5Hash: resource.md5Hash,
    crc32c: resource.crc32c,
    etag: resource.etag,
    contentDisposition: resource.contentDisposition,
    contentEncoding: resource.contentEncoding,
    contentLanguage: resource.contentLanguage,
    cacheControl: resource.cacheControl,
  });
}

/** ISO-8601 → timestamp. An unparseable or absent value stays `undefined`
 *  (→ absent-property error → deny) rather than becoming a NaN timestamp. */
function isoToTimestamp(iso: string | undefined): Timestamp | undefined {
  if (iso === undefined) return undefined;
  const ms = parseStrictIsoMillis(iso);
  if (ms === null) return undefined;
  return Timestamp.fromMillis(ms);
}

/** Build the `request.*` binding; `now` is the evaluation instant in epoch millis. */
export function buildRequestObject(input: EvaluationInput, now: number): Record<string, unknown> {
  const auth = input.request.auth;
  let requestAuth: unknown;
  if (auth === null || auth === undefined) {
    // The production Storage engine represents anonymous auth as an absent
    // property, not a usable null value. Ordinary `request.auth != null`
    // gates still deny, while conditionals cannot incorrectly select a
    // fallback branch from the synthetic null.
    requestAuth = new RuleError('Property auth is undefined on object.');
  } else {
    // Projecting a top-level `tenant` into `token.firebase.tenant` is one
    // cross-surface rule about an identity, not a Storage rules concern, so
    // the sandbox context owns it and every surface reads the same shape.
    // Claims type as ints by `typeClaimNumbers`, shared with Firestore.
    const normalized = normalizeAuthState(auth);
    if (normalized === null) {
      requestAuth = new RuleError('Property auth is undefined on object.');
    } else {
      requestAuth = typeClaimNumbers({ ...normalized, token: normalized.token ?? {} });
    }
  }
  const request: Record<string, unknown> = {
    auth: requestAuth,
    // Production treats an operation without an incoming object (notably
    // delete/read) as an absent binding. A direct null comparison errors just
    // like a property read; neither may turn the missing value into an allow.
    resource:
      input.request.resource !== undefined
        ? omitUndefined(input.request.resource as unknown as Record<string, unknown>)
        : new RuleError('Property resource is undefined on object.'),
    method: input.request.method,
    // A path value, which `request.path[0]` reads by segment.
    path: new StoragePath(input.request.path),
    // The same Timestamp value `timestamp.date(...)` and `timestamp.value(...)`
    // build, so `request.time < timestamp.date(2030, 1, 1)` compares
    // timestamps and `request.time.year()` reads a component.
    time: Timestamp.fromMillis(now),
  };
  return request;
}
