/**
 * RULES-B11 (enforcement wiring) — query-proof gate for `list` reads.
 *
 * Production Firestore enforces "rules are NOT filters": a query (`list`)
 * is evaluated ONCE against its potential result set and REJECTED outright
 * when the rules can't prove every returnable doc is readable — it is never
 * silently truncated to the readable subset, and per-doc `get` rules never
 * filter query results (the `list` rule alone governs queries).
 *
 *   docs: https://firebase.google.com/docs/firestore/security/rules-query
 *   "Rules are not filters … the query must be guaranteed to return only
 *    documents that the rules allow the client to read. Otherwise the
 *    request fails — even if the actual result set would have been allowed."
 *
 * The pure PROVABLE-or-REJECT decision lives in `rules/simulator/query-proof.ts`.
 * This module resolves which `list`/`read` rules match a collection path
 * (using the simulator's shared match collector), asks `evaluateQueryProof`
 * per rule (OR semantics), and provides both the simulator's `queryProof`
 * report and the sandbox's `RulesListAuthorizer` proof + repro rendering.
 */
import { assembleExpression as printExpression } from '../grammar/FirestoreAssembler.js';
import type {
  AllowRule,
  FirestoreRules,
  MatchBlock,
} from '../grammar/FirestoreAST.js';
import { topLevelMatches } from '../grammar/service-blocks.js';
import { resolveAuthoredSourceLoc } from '../modules/resolver-core.js';
import type {
  EvaluatedRuleInfo,
  ListQuery,
  SerializedListQueryWrapper,
} from '../test/spec.js';
import { indexRulesetScopes, type MatchResult } from './match-resolution.js';
import { getListBlockSteps, setListBlockSteps, type ListBlockStep } from './list-proof-budget.js';
import { collectRootMatches } from './root-match.js';
import {
  evaluateQueryProof,
  type QueryConstraints,
  type QueryProofResidual,
  type QueryWhereConstraint,
  type QueryWhereValue,
} from './query-proof.js';
import {
  buildRuleBudgetCondition,
  computeWhereDomains,
  formatQueryScalarForRemediation,
  type FormatQueryScalarOptions,
  type RulesScalar,
} from './query-proof-residual.js';
import { reviveFirestoreNumbers } from './firestore-values.js';
import { buildListRuleFunctionScope } from './list-rule-path-proof.js';
import { RulesValue } from './wrappers/base.js';

export type {
  FormatQueryScalarOptions,
  QueryConstraints,
  QueryProofResidual,
  QueryWhereConstraint,
  QueryWhereValue,
};

/** Local proof evidence. These categories do not claim a Firebase decision. */
export interface QueryProofFailure {
  kind: 'unsupported-predicate' | 'unsupported-path' | 'constraints-not-satisfied';
  reason: string;
  residual: QueryProofResidual;
  /** Location of the rejected predicate, which may be inside a helper. */
  predicate?: QueryProofFailure['rule'];
  rule?: {
    line?: number;
    col?: number;
    column?: number;
    file?: string;
    citation?: string;
    expression?: string;
  };
}

export interface QueryProofDiagnostic {
  kind: QueryProofFailure['kind'] | 'residual-denied' | 'no-rule';
  /** Rejected rules, in source order. None were evaluated against stored rows. */
  failures: QueryProofFailure[];
  /** Complete query identity, separate from the conservative proof projection. */
  query?: unknown;
}

/**
 * Separate static list-query proof verdict reported alongside per-document
 * evaluation on `TestResult` / `CaseResult` / `Explanation` (#371).
 */
export interface ListQueryProofReport {
  /** Static list-query proof verdict, separate from per-document `decision`. */
  verdict: 'PROVABLE' | 'UNPROVABLE' | 'NO_RULE';
  /** True when the rules can statically prove every document the query could return is readable. */
  provable: boolean;
  /** Specific proof classification (`'provable'`, `'no-rule'`, or the primary failure kind). */
  kind: 'provable' | 'no-rule' | QueryProofFailure['kind'];
  /** Rules rejected by static query proof, in source order. */
  failures: QueryProofFailure[];
  /** Human-readable explanation when `verdict === 'UNPROVABLE'`. */
  reason?: string;
  /** Structured account of missing/mismatched `where(...)` equalities when `verdict === 'UNPROVABLE'`. */
  residual?: QueryProofResidual;
  /** Narrowing `where(...)` remediation when `verdict === 'UNPROVABLE'` and equalities can discharge the rule. */
  remediation?: string;
  /** Source location and expression of the primary unprovable rule when `verdict === 'UNPROVABLE'`. */
  rule?: EvaluatedRuleInfo;
}

/** Ready-to-run repro for a rejected list query (#371). */
export interface QueryRepro {
  /** Ready-to-run CLI command that simulates the rejected list query. */
  command: string;
  /** Copy-pasteable TestCase / FirestoreCase fixture object for `simulate()`. */
  testCase: {
    description: string;
    expectation: 'ALLOW';
    method: 'list';
    path: string;
    auth: { uid: string; token?: Record<string, unknown> } | null;
    query?: ListQuery;
  };
}

/** Auth shape the sandbox threads through reads (`Operation['auth']`). */
type ReadAuth = { uid: string; token?: Record<string, unknown> } | null;

/** What the proof decided for a `list` request. */
export type ListProofVerdict =
  /** At least one matching `list`/`read` rule is provable for this query.
   *  Residual evaluation MUST use only `evaluationAst`, which removes
   *  unprovable sibling rules that could otherwise allow from local state.
   *  `syntheticResource` is independent of any user-addressable placeholder
   *  document and contains only query-pinned equality fields. */
  | {
      kind: 'provable';
      failures: QueryProofFailure[];
      evaluationAst: FirestoreRules;
      syntheticResource: Record<string, unknown>;
    }
  /** Every matching rule depends on per-document data the query's
   *  constraints cannot prove safe — Pyric rejects the whole query.
   *  `residual` is the structured account (missing / mismatched equalities,
   *  or an out-of-scope shape) that the denial site renders remediation from. */
  | { kind: 'unprovable'; failures: QueryProofFailure[]; reason: string; residual: QueryProofResidual; rule?: EvaluatedRuleInfo }
  /** No match block / no list rules — let simulate() default-deny exactly
   *  as it does today (the proof has nothing to add). */
  | { kind: 'no-rule' };

/**
 * Decide provability of a `list` on `relPath` (the placeholder doc path,
 * e.g. `posts/__listPlaceholder__`) under `auth` and the query's structured
 * `constraints`. Pure — parses nothing, reads no state.
 */
export function proveListQuery(
  ast: FirestoreRules | null,
  relPath: string,
  auth: ReadAuth,
  constraints: QueryConstraints,
  sourceString?: string,
): ListProofVerdict {
  const isAstDefined = ast !== null;
  if (isAstDefined === false) {
    return { kind: 'no-rule' };
  }
  indexRulesetScopes(ast!);
  // Like handler.ts, the root match is compared with the request first, and
  // its children resolve what it leaves with every enclosing helper in scope.
  const rootFunctions = [
    ...(ast!.functions ?? []),
    ...(ast!.service.functions ?? []),
  ];
  const matches: MatchResult[] = collectRootMatches(ast!, relPath, rootFunctions);
  const isMatchesEmpty = matches.length === 0;
  if (isMatchesEmpty) {
    return { kind: 'no-rule' };
  }

  // OR semantics across allow rules: ANY provable rule makes the query
  // provable. Residual simulation receives ONLY those provable rules, so an
  // unprovable sibling cannot grant from a concrete placeholder document,
  // while preceding unprovable rules still charge the per-request expression
  // and lookup budgets via `ListBlockStep`.
  const failures: QueryProofFailure[] = [];
  const provableRules = new Map<AllowRule, AllowRule>();
  const evaluatedBlocks = new Map<MatchBlock, ListBlockStep[]>();
  let applicableRuleCount = 0;
  for (const match of matches) {
    const functionScope = buildListRuleFunctionScope(match.functions);
    const fnMap = functionScope.functions;
    const candidateVariables = new Set(match.candidateVariables);
    const recursiveVariables = new Set(match.recursiveVariables ?? []);
    const parentPathVariables: Record<string, string> = Object.create(null);
    for (const [k, v] of Object.entries(match.pathVariables)) {
      if (!candidateVariables.has(k) && !recursiveVariables.has(k)) {
        parentPathVariables[k] = v;
      }
    }
    const pathInvariance = {
      candidateVariables,
      ambiguousNames: functionScope.ambiguousNames,
    };
    const projectBudgetRule = (rule: AllowRule): AllowRule => {
      const projectedCondition = buildRuleBudgetCondition(
        rule.condition,
        constraints,
        fnMap,
        match.functionScopes,
        pathInvariance,
      );
      return projectedCondition === rule.condition
        ? rule
        : { ...rule, condition: projectedCondition };
    };
    const evaluateGrantCandidate = (rule: AllowRule, ruleIndex: number, blockSteps: ListBlockStep[]): void => {
      const hasListOrRead = rule.operations.some((op) => op === 'list' || op === 'read');
      if (hasListOrRead === false) {
        return;
      }
      applicableRuleCount++;
      // `auth.uid` is threaded into the proof so the canonical owner pattern
      // can be discharged by a matching query equality. Residual simulation
      // still evaluates the real auth value against the synthetic resource.
      const result = evaluateQueryProof(
        rule.condition,
        constraints,
        fnMap,
        auth?.uid,
        parentPathVariables,
        match.functionScopes,
        pathInvariance,
      );
      const isProvable = result.provable === true;
      if (isProvable) {
        const projectedRule = result.residualCondition ? { ...rule, condition: result.residualCondition } : rule;
        provableRules.set(rule, projectedRule);
        blockSteps.push({ kind: 'grant', rule: projectedRule, index: ruleIndex });
      } else {
        blockSteps.push({ kind: 'budget', rule: projectBudgetRule(rule), index: ruleIndex });
      }
      const failure = result.provable ? result.proofFailure : result;
      if (failure) {
        failures.push({
          kind: failure.kind, reason: failure.reason, residual: failure.residual,
          rule: proofRuleInfo(rule, sourceString),
          ...(failure.residual.predicate ? { predicate: proofSourceInfo(
            failure.residual.predicate, failure.residual.predicateLoc ?? rule.loc, sourceString,
          ) } : {}),
        });
      }
    };

    const blockSteps: ListBlockStep[] = [];
    const priorBlockSteps = getListBlockSteps(match.block);
    if (priorBlockSteps) {
      for (const priorStep of priorBlockSteps) {
        if (priorStep.kind === 'budget') {
          blockSteps.push({
            kind: 'budget',
            rule: projectBudgetRule(priorStep.rule),
            index: priorStep.index,
          });
        } else {
          evaluateGrantCandidate(priorStep.rule, priorStep.index, blockSteps);
        }
      }
    } else {
      for (let ruleIndex = 0; ruleIndex < match.block.allows.length; ruleIndex++) {
        evaluateGrantCandidate(match.block.allows[ruleIndex]!, ruleIndex, blockSteps);
      }
    }
    if (!evaluatedBlocks.has(match.block)) {
      evaluatedBlocks.set(match.block, blockSteps);
    }
  }
  const isAppCountZero = applicableRuleCount === 0;
  if (isAppCountZero) {
    return { kind: 'no-rule' };
  }
  const isProvableEmpty = provableRules.size === 0;
  if (isProvableEmpty) {
    const first = failures[0]!;
    return {
      kind: 'unprovable',
      failures,
      reason: first.reason,
      residual: first.residual,
      ...(first.rule ? { rule: { ...first.rule, verdict: 'deny' as const } } : {}),
    };
  }

  return {
    kind: 'provable',
    failures,
    evaluationAst: projectRules(ast!, provableRules, evaluatedBlocks),
    syntheticResource: syntheticResourceFromWheres(constraints),
  };
}

/** Resolve against authored source before assembly removes rejected siblings. */
function proofRuleInfo(rule: AllowRule, source = ''): NonNullable<QueryProofFailure['rule']> {
  return proofSourceInfo(printExpression(rule.condition), rule.loc, source);
}

function proofSourceInfo(expression: string, loc: AllowRule['loc'], source = ''): NonNullable<QueryProofFailure['rule']> {
  if (!loc) return { expression };
  const { line, col, file } = loc;
  const authored = resolveAuthoredSourceLoc(source, line, col, file, expression);
  if (authored) return { ...authored, column: authored.col, expression: authored.expression ?? expression };
  return { line, col, column: col, file: file ?? 'firestore.rules',
    citation: `${file ?? 'firestore.rules'}:${line}:${col}`, expression };
}

// ─── Proof/execution projection ──────────────────────────────────

/** Preserve match paths and helper scopes while removing every rule the
 * static proof did not approve. This keeps residual execution and proof on
 * the exact same set of potentially granting rules. */
function projectRules(
  ast: FirestoreRules,
  retained: ReadonlyMap<AllowRule, AllowRule>,
  evaluatedBlocks: ReadonlyMap<MatchBlock, readonly ListBlockStep[]>,
): FirestoreRules {
  const projectBlock = (block: MatchBlock): MatchBlock => {
    const projected: MatchBlock = {
      ...block,
      allows: block.allows.filter((rule) => retained.has(rule)).map((rule) => retained.get(rule)!),
      children: block.children.map(projectBlock),
    };
    const steps = evaluatedBlocks.get(block);
    if (steps && steps.some((step) => step.kind === 'budget')) {
      setListBlockSteps(projected, steps);
    }
    return projected;
  };
  const projectedRoots = topLevelMatches(ast.service).map(projectBlock);
  return {
    ...ast,
    service: {
      ...ast.service,
      match: projectedRoots[0] ?? ast.service.match,
      matches: projectedRoots,
    },
  };
}

// ─── Synthetic resource construction ─────────────────────────────────────

/**
 * Build the representative `resource.data` for the residual evaluation:
 * every field the query's intersected `==` / `in` constraints pin to a single
 * scalar value. Fields the query does not pin stay ABSENT, so a rule conjunct
 * reading them errors (→ deny) rather than passing vacuously.
 */
function syntheticResourceFromWheres(constraints: QueryConstraints): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [field, values] of computeWhereDomains(constraints)) {
    if (values.length === 1) {
      Object.defineProperty(out, field, {
        value: values[0],
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
  }
  return out;
}

// ─── Query shape conversions ─────────────────────────────────────────────

function reviveWhereScalar(val: unknown): RulesScalar {
  if (
    val !== null &&
    typeof val === 'object' &&
    !(val instanceof RulesValue) &&
    typeof (val as { __type?: unknown }).__type === 'string'
  ) {
    const revived = reviveFirestoreNumbers(val);
    if (revived instanceof RulesValue) return revived as RulesScalar;
  }
  return val as RulesScalar;
}

function isWhereScalarArray(value: QueryWhereValue): value is readonly RulesScalar[] {
  return Array.isArray(value);
}

function toListQueryScalar(
  val: RulesScalar,
): string | number | boolean | null | SerializedListQueryWrapper {
  if (typeof val === 'bigint') return Number(val);
  if (val instanceof RulesValue) return val.toJSON() as SerializedListQueryWrapper;
  return val;
}

/** Convert a `ListQuery` from a `TestCase` / `FirestoreCase` into `QueryConstraints`. */
export function listQueryToConstraints(query?: ListQuery): QueryConstraints {
  if (!query) return {};
  return {
    ...(query.where !== undefined
      ? {
          where: query.where.map((w) => ({
            field: w.field,
            op: w.op,
            value: Array.isArray(w.value)
              ? w.value.map(reviveWhereScalar)
              : reviveWhereScalar(w.value),
          })),
        }
      : {}),
    ...(query.limit !== undefined ? { limit: query.limit } : {}),
    ...(query.offset !== undefined ? { offset: query.offset } : {}),
    ...(query.orderBy !== undefined ? { orderBy: query.orderBy } : {}),
  };
}

/** Convert `QueryConstraints` back to a `ListQuery` when any constraint is present. */
export function listQueryFromConstraints(structured: QueryConstraints): ListQuery | undefined {
  const hasWhere = structured.where !== undefined && structured.where.length > 0;
  if (!hasWhere && structured.limit == null && structured.offset == null && structured.orderBy == null) {
    return undefined;
  }
  return {
    ...(hasWhere
      ? {
          where: structured.where!.map((w) => ({
            field: w.field,
            op: w.op,
            value: isWhereScalarArray(w.value)
              ? w.value.map(toListQueryScalar)
              : toListQueryScalar(w.value),
          })),
        }
      : {}),
    ...(structured.limit != null ? { limit: structured.limit } : {}),
    ...(structured.offset != null ? { offset: structured.offset } : {}),
    ...(structured.orderBy != null ? { orderBy: structured.orderBy } : {}),
  };
}

// ─── Remediation & Repro rendering ───────────────────────────────────────

/**
 * Render query-side, narrowing-only remediation from an unprovable query's
 * residual — the `where(...)` clauses the caller can ADD (or correct) so the
 * `list` rule's per-doc equalities are discharged. The suggestion never touches
 * the rule (weakening a rule is never the right fix for an over-broad query).
 *
 * Returns `undefined` when the residual is only an out-of-scope shape
 * (disjunction / range / `in` / nested path): no equality constraint can prove
 * it, so there is nothing narrowing to suggest.
 */
export function renderQueryRemediation(residual: QueryProofResidual): string | undefined {
  const lines: string[] = [];
  for (const m of residual.missing) {
    if (m.fromAuthUid) {
      lines.push(
        `  .where('${m.field}', '==', request.auth.uid)   // request.auth.uid is ${formatQueryScalarForRemediation(m.expectedValue)}`,
      );
    } else {
      lines.push(`  .where('${m.field}', '==', ${formatQueryScalarForRemediation(m.expectedValue)})`);
    }
  }
  for (const m of residual.mismatched) {
    const expectedText = formatQueryScalarForRemediation(m.expectedValue);
    const actualText = formatQueryScalarForRemediation(m.actualValue);
    lines.push(
      `  .where('${m.field}', '==', ${expectedText})   ` +
      `// the query pins ${actualText}, but the rule requires ${expectedText}`,
    );
  }
  if (lines.length === 0) return undefined;
  const header =
    'The list rule requires per-document equalities the query does not guarantee. ' +
    'Add the matching where(...) constraint(s) so every returned document satisfies the rule:';
  return `${header}\n${lines.join('\n')}`;
}

function quoteCliArg(value: string): string {
  if (/^[A-Za-z0-9_./:-]+$/.test(value)) return value;
  return `'${value.replace(/'/g, "'\\''")}'`;
}

/**
 * Build a ready-to-run repro (CLI command + fixture `TestCase`) from a rejected
 * `list` request so failure-to-regression-test is copy-paste (#371).
 */
export function buildQueryRepro(input: {
  path: string;
  auth: ReadAuth;
  constraints: QueryConstraints;
}): QueryRepro {
  const query = listQueryFromConstraints(input.constraints);
  const auth = input.auth
    ? {
        uid: input.auth.uid,
        ...(input.auth.token && Object.keys(input.auth.token).length > 0 ? { token: input.auth.token } : {}),
      }
    : null;
  const testCase: QueryRepro['testCase'] = {
    description: `list ${input.path}`,
    expectation: 'ALLOW',
    method: 'list',
    path: input.path,
    auth,
    ...(query ? { query } : {}),
  };
  const args = [
    'pyric rules simulate --service firestore --operation list',
    `--path ${quoteCliArg(input.path)}`,
    ...(auth ? [`--uid ${quoteCliArg(auth.uid)}`] : []),
    ...(query ? [`--query '${JSON.stringify(query).replace(/'/g, "'\\''")}'`] : []),
  ];
  return {
    command: args.join(' '),
    testCase,
  };
}

/** Render a human-readable copy-paste repro block for terminal/error output (#371). */
export function renderQueryRepro(input: {
  path: string;
  auth: ReadAuth;
  constraints: QueryConstraints;
}): string {
  const repro = buildQueryRepro(input);
  return [
    'Reproduce with:',
    `  ${repro.command}`,
    `  Fixture case: ${JSON.stringify(repro.testCase)}`,
  ].join('\n');
}
