/**
 * Timestamp wrapper for Firestore Rules `timestamp` type — Item 1.3.
 *
 * Closes the entire `Timestamp` type gap (was "❌ entire type" in the
 * REBUILD_PLAN Reference Inventory) and the `request.time` type bug
 * (was an ISO string — see REBUILD_PLAN Risk 1).
 *
 * Reference surface (12 instance methods):
 *   date, day, dayOfWeek, dayOfYear, hours, minutes, month, nanos,
 *   seconds, time, toMillis, year
 *
 * Construction (atomic flip per REBUILD_PLAN Risk 3):
 *   - timestamp.date(y, m, d)            month is 1-based
 *   - timestamp.value(epochMs)            millis since Unix epoch
 *   - request.time                        wrapped by handler.ts
 *   - serverTimestamp sentinel resolution wrapped by handler.ts
 *
 * Internal storage per 0.C: plain `{ seconds, nanos }` Numbers.
 * Comparison and arithmetic go field-wise via binaryOp; valueOf() is a
 * legacy-fallback only and silently truncates sub-ms precision.
 *
 * Canonical form: nanos in `[0, 999_999_999]` non-negative (protobuf
 * Timestamp spec). Negative epoch seconds are allowed (pre-1970) but
 * nanos always normalize positive — `equals()` is a straight field
 * compare without per-call normalization.
 */
import { RulesValue, NO_OP, ValueRangeError, type NoOp } from './base.js';
import { Duration } from './duration.js';
import { parseStrictIsoMillis } from '../../test/case-refusals.js';

const NANOS_PER_SECOND = 1_000_000_000;
const MS_PER_DAY = 86_400_000;
const SECONDS_PER_DAY = 86_400;
const SECONDS_PER_MINUTE = 60;
/** 0001-01-01T00:00:00Z, production's earliest timestamp. */
const MIN_SECONDS = -62_135_596_800;
/** 9999-12-31T23:59:59Z; with nanos up to 999,999,999, the latest. */
const MAX_SECONDS = 253_402_300_799;
/** Production's evaluation error for a timestamp outside its range, from the capture's diagnostics. */
export const TIMESTAMP_NOT_VALID =
  'Timestamp is not valid. Seconds must be in range [-62,135,596,800, +253,402,300,799]. Nanos must be in range [0, +999,999,999].';

/**
 * Roll over-/under-flow nanos into seconds and force nanos non-negative.
 * Uses `Math.floor` (not truncation) so negative nanos correctly borrow
 * a second: `(0, -1)` → `(-1, 999_999_999)` rather than `(0, -1)`.
 */
function normalize(seconds: number, nanos: number): { seconds: number; nanos: number } {
  const carry = Math.floor(nanos / NANOS_PER_SECOND);
  return {
    seconds: seconds + carry,
    nanos: nanos - carry * NANOS_PER_SECOND,
  };
}

/** True for whole epoch seconds production can hold; false for NaN and infinities. */
function isInRange(seconds: number): boolean {
  return Number.isFinite(seconds) && seconds >= MIN_SECONDS && seconds <= MAX_SECONDS;
}

export class Timestamp extends RulesValue {
  readonly typeName = 'timestamp';
  readonly seconds: number;
  readonly nanos: number;

  /**
   * Throws production's "Timestamp is not valid" error (a {@link ValueRangeError}) when
   * the normalized instant is outside 0001-01-01T00:00:00Z to
   * 9999-12-31T23:59:59.999999999Z or is not finite, so arithmetic past the
   * range, and a NaN instant, never become a value.
   */
  constructor(seconds: number, nanos: number) {
    super();
    const norm = normalize(seconds, nanos);
    if (!isInRange(norm.seconds)) throw new ValueRangeError(TIMESTAMP_NOT_VALID);
    this.seconds = norm.seconds;
    this.nanos = norm.nanos;
  }

  /** `timestamp.value(epochMs)` — milliseconds since Unix epoch. */
  static fromMillis(ms: number): Timestamp {
    if (!Number.isFinite(ms)) throw new ValueRangeError(TIMESTAMP_NOT_VALID);
    const seconds = Math.floor(ms / 1000);
    const remainderMs = ms - seconds * 1000;
    return new Timestamp(seconds, remainderMs * 1_000_000);
  }

  /** `timestamp.date(y, m, d)` — midnight UTC; month is 1-based. */
  static fromYMD(year: number, month: number, day: number): Timestamp {
    if (
      !Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day) ||
      year < 1 || year > 9999 || month < 1 || month > 12 || day < 1 || day > 31
    ) {
      throw new RangeError(`Date is not valid. year: ${year}, month: ${month} day: ${day}.`);
    }
    const d = new Date(0);
    d.setUTCFullYear(year, month - 1, day);
    d.setUTCHours(0, 0, 0, 0);
    if (d.getUTCFullYear() !== year || d.getUTCMonth() !== month - 1 || d.getUTCDate() !== day) {
      throw new RangeError(`Date is not valid. year: ${year}, month: ${month} day: ${day}.`);
    }
    return Timestamp.fromMillis(d.getTime());
  }

  /**
   * Parse an ISO-8601 string into a Timestamp. Used by `handler.ts` to
   * convert `tc.requestTime` (kept as ISO string for backwards-compat
   * with the prod Test API) into the wrapper. Sub-millisecond precision
   * in the input string is dropped because `Date.parse` only sees ms —
   * acceptable here because `tc.requestTime` is a developer-facing pin
   * (no nanosecond precision test exists for it).
   */
  static fromIsoString(iso: string): Timestamp {
    const ms = parseStrictIsoMillis(iso);
    if (ms === null) throw new ValueRangeError(TIMESTAMP_NOT_VALID);
    return Timestamp.fromMillis(ms);
  }

  toMillis(): number {
    return this.seconds * 1000 + Math.floor(this.nanos / 1_000_000);
  }

  /**
   * Convert to a JavaScript `Date` (millisecond precision).
   * Sub-millisecond nanos are dropped — same behaviour as the real
   * `firebase/firestore` `Timestamp.toDate()`.
   */
  toDate(): Date {
    return new Date(this.toMillis());
  }

  valueOf(): number {
    return this.toMillis();
  }

  /**
   * ISO-8601 UTC with 9-digit nanosecond precision. Standard
   * `Date.toISOString()` only carries millisecond precision; we
   * substitute the full nanos to preserve sub-ms detail for
   * debugMessages.
   */
  toString(): string {
    const isoMs = new Date(this.toMillis()).toISOString();
    const nanoStr = this.nanos.toString().padStart(9, '0');
    return isoMs.replace(/\.\d{3}Z$/, `.${nanoStr}Z`);
  }

  toJSON(): unknown {
    return { __type: 'timestamp', seconds: this.seconds, nanos: this.nanos };
  }

  equals(other: unknown): boolean {
    return (
      other instanceof Timestamp &&
      this.seconds === other.seconds &&
      this.nanos === other.nanos
    );
  }

  /**
   * Date components (year/month/day/hours/etc.) derive from JS `Date`
   * which only handles millisecond precision. The Timestamp's `seconds`
   * field already encodes whole-seconds, so date math is exact even
   * when sub-ms nanos are present. `dayOfWeek` follows ISO 8601:
   * Monday = 1, Sunday = 7.
   *
   * `seconds()` and `nanos()` are time-of-day components like `hours()`
   * and `minutes()`: the seconds of the minute and the nanoseconds of the
   * second. The `seconds` field is epoch seconds; `toMillis()` is the epoch
   * accessor rules see. Captured by rules-firestore-timestamp-component-accessors
   * and rules-storage-stdlib-timestamp-duration.
   */
  callMethod(method: string, args: unknown[]): unknown | NoOp {
    const requireZeroArgs = () => {
      if (args.length !== 0) {
        throw new RangeError(
          `Incorrect number of arguments. Received: ${args.length}. Expected: timestamp.${method}().`,
        );
      }
    };
    switch (method) {
      case 'seconds':
        requireZeroArgs();
        return ((this.seconds % SECONDS_PER_MINUTE) + SECONDS_PER_MINUTE) % SECONDS_PER_MINUTE;
      case 'nanos':
        requireZeroArgs();
        return this.nanos;
      case 'toMillis':
        requireZeroArgs();
        return this.toMillis();
      case 'year':
        requireZeroArgs();
        return this.asDate().getUTCFullYear();
      case 'month':
        requireZeroArgs();
        return this.asDate().getUTCMonth() + 1;
      case 'day':
        requireZeroArgs();
        return this.asDate().getUTCDate();
      case 'hours':
        requireZeroArgs();
        return this.asDate().getUTCHours();
      case 'minutes':
        requireZeroArgs();
        return this.asDate().getUTCMinutes();
      case 'dayOfWeek': {
        requireZeroArgs();
        const jsDay = this.asDate().getUTCDay(); // 0=Sun .. 6=Sat
        return jsDay === 0 ? 7 : jsDay;
      }
      case 'dayOfYear': {
        requireZeroArgs();
        const d = this.asDate();
        const startOfYear = Date.UTC(d.getUTCFullYear(), 0, 1);
        return Math.floor((this.toMillis() - startOfYear) / MS_PER_DAY) + 1;
      }
      case 'date':
        requireZeroArgs();
        // Same year/month/day, time-of-day zeroed.
        return Timestamp.fromYMD(
          this.asDate().getUTCFullYear(),
          this.asDate().getUTCMonth() + 1,
          this.asDate().getUTCDate(),
        );
      case 'time': {
        requireZeroArgs();
        // Time-of-day as Duration. Compute from seconds field directly
        // so sub-ms nanos survive (JS Date would truncate them).
        const secOfDay = ((this.seconds % SECONDS_PER_DAY) + SECONDS_PER_DAY) % SECONDS_PER_DAY;
        const h = Math.floor(secOfDay / 3600);
        const m = Math.floor((secOfDay % 3600) / 60);
        const s = secOfDay % 60;
        return Duration.fromTime(h, m, s, this.nanos);
      }
      default:
        return NO_OP;
    }
  }

  private asDate(): Date {
    return new Date(this.toMillis());
  }

  /**
   * Cross-type arithmetic per REBUILD_PLAN Operators table:
   *   Timestamp + Duration → Timestamp
   *   Timestamp - Duration → Timestamp
   *   Timestamp - Timestamp → Duration
   * Plus `< <= > >=` for two Timestamps via field-wise compareTo.
   *
   * `Duration + Timestamp` (commutative) is reachable through the
   * evaluator's right-side dispatch on `+` — Duration.binaryOp returns
   * NO_OP, then `rv` (Timestamp).binaryOp(+, lv) lands here.
   */
  binaryOp(op: string, other: unknown): unknown | NoOp {
    if (other instanceof Timestamp) {
      switch (op) {
        case '-':
          return new Duration(this.seconds - other.seconds, this.nanos - other.nanos);
        case '<':
          return this.compareTo(other) < 0;
        case '<=':
          return this.compareTo(other) <= 0;
        case '>':
          return this.compareTo(other) > 0;
        case '>=':
          return this.compareTo(other) >= 0;
        default:
          return NO_OP;
      }
    }
    if (other instanceof Duration) {
      switch (op) {
        case '+':
          return new Timestamp(this.seconds + other.seconds, this.nanos + other.nanos);
        case '-':
          return new Timestamp(this.seconds - other.seconds, this.nanos - other.nanos);
        default:
          return NO_OP;
      }
    }
    return NO_OP;
  }

  private compareTo(other: Timestamp): number {
    if (this.seconds !== other.seconds) return this.seconds - other.seconds;
    return this.nanos - other.nanos;
  }
}
