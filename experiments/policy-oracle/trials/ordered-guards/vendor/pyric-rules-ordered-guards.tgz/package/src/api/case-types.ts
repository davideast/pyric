/**
 * The public case and result vocabulary for Firestore, Storage and RTDB.
 *
 * The cases are deliberately not unified — each service takes a different
 * request shape (Firestore is method + document path + resource/data;
 * Storage is method + bucket + object path + object metadata; RTDB is
 * operation + tree path + data/newData), and collapsing them into one shape
 * would force every field to be optional and every reader to guess which
 * part applies. They share the assertion
 * adapter (`assertCase`, with `explainCase` as its renderer) and the unified
 * {@link RuleIssue}, nothing more.
 */

import type {
  FirestoreMethod,
  FunctionMock,
  ListQuery,
  RuleEvaluation,
  PathResolutionTrace,
  RulesResourceLimit,
  TestIdentity,
  WriteMode,
} from '../test/spec.js';
import type { EvaluatedRuleInfo } from '../test/spec.js';
import type { ListQueryProofReport } from '../simulator/list-query-proof.js';
import type { RtdbCoverageSummary } from '../rtdb/coverage.js';
import type { RtdbRuleEvaluation } from '../rtdb/simulation/spec.js';
import type {
  StorageAuth,
  StorageRequestResource,
  StorageResource,
} from '../storage/rules.js';
import type { StorageMatchedRule } from '../storage/rules-evaluator.js';

export type { RtdbRuleEvaluation };

// ─── Firestore ───────────────────────────────────────────────────────

/**
 * One Firestore rules case: a single request plus the outcome it should
 * produce. Structurally identical to the engine's `TestCase` — re-exported
 * here under the public name so callers never reach into the engine seam.
 */
export interface FirestoreCase {
  /** Human-readable description of what this case verifies. */
  description: string;
  /** Expected outcome. */
  expectation: 'ALLOW' | 'DENY';
  /** Firestore method under test. */
  method: FirestoreMethod;
  /** Document path, e.g. `"users/alice"`. */
  path: string;
  /** Auth context; `null`/omitted for unauthenticated. */
  auth?: TestIdentity | null;
  /** `request.resource.data` for write operations. */
  data?: Record<string, unknown>;
  /** Existing document data (`resource.data`). */
  resource?: Record<string, unknown>;
  /** Explicit write semantics — controls update-merge and getAfter()
   *  projection. Omit to treat `data` as the full after-state. */
  writeMode?: WriteMode;
  /** Mock `get()` / `exists()` calls the rules make. */
  functionMocks?: FunctionMock[];
  /** `request.query` payload (list ops only): limit/offset/orderBy. */
  query?: ListQuery;
  /** Override for `request.time` (ISO-8601). Defaults to wallclock. */
  requestTime?: string;
}

/** The outcome of running one Firestore case through `simulate`. Never a
 *  thrown error — a denied or abstained case is data, not an exception. */
export interface CaseResult {
  /** The case that produced this result. */
  case: FirestoreCase;
  description: string;
  expectation: 'ALLOW' | 'DENY';
  /** The engine's absolute verdict, independent of expectation. */
  decision: 'ALLOW' | 'DENY' | 'UNSUPPORTED';
  /** `true` when `decision` matched `expectation`. */
  passed: boolean;
  /** `true` when the simulator abstained on a feature it does not
   *  implement — neither a pass nor a genuine failure. */
  unsupported: boolean;
  /** Per-rule evaluation entries in source order. */
  trace: RuleEvaluation[];
  /** Top-level diagnostic strings. */
  notes: string[];
  /** Which match blocks the resolver considered and where each fell apart. */
  pathResolution?: PathResolutionTrace;
  /**
   * Expressions the request evaluated, in the unit of production's
   * per-request limit of 1000, across every allow rule and match block it
   * reached. `1000 - evaluatedExpressions` is the request's margin. See
   * `TestResult.evaluatedExpressions` for the unit.
   */
  evaluatedExpressions: number;
  /** The per-request limit that stopped the request, when one did. A
   *  request past 1000 expressions is DENY with `kind: 'expressions'`
   *  and production's message. */
  resourceLimit?: RulesResourceLimit;
  /** Static list-query proof verdict for `list` cases, separate from per-document `decision` (#371). */
  queryProof?: ListQueryProofReport;
}

/** The structured account of why one Firestore case resolved as it did. */
export interface Explanation {
  decision: 'ALLOW' | 'DENY' | 'UNSUPPORTED';
  expectation: 'ALLOW' | 'DENY';
  passed: boolean;
  unsupported: boolean;
  /** The deciding `allow` rule (line, condition text, sub-expression
   *  trace), when one was evaluated. Absent on default-deny / abstain. */
  deciding?: EvaluatedRuleInfo;
  trace: RuleEvaluation[];
  pathResolution?: PathResolutionTrace;
  notes: string[];
  /** Expressions the request evaluated; see {@link CaseResult.evaluatedExpressions}. */
  evaluatedExpressions: number;
  /** The per-request limit that stopped the request, when one did. */
  resourceLimit?: RulesResourceLimit;
  /** Static list-query proof verdict for `list` cases, separate from per-document `decision` (#371). */
  queryProof?: ListQueryProofReport;
}

/** Aggregate of a `simulate(cases)` run. Counts partition the cases:
 *  `passed + failed + unsupported === cases.length`. */
export interface SimulationSummary {
  passed: number;
  failed: number;
  unsupported: number;
  cases: CaseResult[];
}

// ─── Storage ─────────────────────────────────────────────────────────

/**
 * The rules verb a Storage case evaluates, as `request.method` reads it.
 * `read` evaluates `get` and then `list`, and allows when either does. There
 * is no `write`: production binds one granular verb to each write (an upload
 * is a `create`, a metadata update an `update`), so a case names that verb.
 */
export type StorageCaseMethod = 'read' | 'get' | 'list' | 'create' | 'update' | 'delete';

/**
 * One Storage rules case: a single request plus the outcome it should
 * produce, in the shape of the Rules Test API's Storage test case. Every
 * binding is taken as given; nothing is filled in.
 */
export interface StorageCase {
  /** Human-readable description of what this case verifies. */
  description: string;
  /** Expected outcome. */
  expectation: 'ALLOW' | 'DENY';
  /** The verb `request.method` is bound to. */
  method: StorageCaseMethod;
  /**
   * The bucket name the rules see in `match /b/{bucket}/o`, such as
   * `demo-app.appspot.com`. A `gs://` URL reads as its bucket name. Omit it
   * to use the ruleset's `bucket` option.
   */
  bucket?: string;
  /** The object's path within the bucket, such as `users/alice/a.txt`. */
  path: string;
  /** `request.auth`; `null` or omitted for an unauthenticated request. */
  auth?: StorageAuth | null;
  /** `request.resource`, the object a `create` or `update` would store.
   *  Production leaves `request.resource` unset for `read`, `get`, `list`
   *  and `delete`, so a case of those that carries it is UNSUPPORTED. */
  requestResource?: StorageRequestResource;
  /** `resource`, the stored object. Omit it when no object exists. */
  resource?: StorageResource | null;
  /**
   * The documents `firestore.get()` and `firestore.exists()` read, keyed by
   * path relative to the database (`users/alice`). A missing key is a
   * missing document. Omit it when the rules read no Firestore document: a
   * case whose rules read one without it is UNSUPPORTED.
   */
  firestore?: Record<string, Record<string, unknown>>;
  /** Override for `request.time` (ISO-8601). Defaults to wallclock. */
  requestTime?: string;
}

/** The outcome of running one Storage case through `simulate`. */
export interface StorageCaseResult {
  /** The case that produced this result. */
  case: StorageCase;
  description: string;
  expectation: 'ALLOW' | 'DENY';
  /** Names the result a Storage one, apart from Firestore and RTDB results. */
  service: 'storage';
  /** The bucket name the rules saw, or absent when the case named none. */
  bucket?: string;
  /** The engine's absolute verdict, independent of expectation. */
  decision: 'ALLOW' | 'DENY' | 'UNSUPPORTED';
  /** `true` when `decision` matched `expectation`. */
  passed: boolean;
  /** `true` when the case could not be evaluated as given. */
  unsupported: boolean;
  /** The allow rule that allowed the request, or the last one checked on a
   *  denial. Absent when no allow rule covered the request. */
  decidingRule?: StorageMatchedRule;
  /** Why the request was denied, one entry per allow rule that did not
   *  allow it, or why the case could not be evaluated. */
  reasons: string[];
  /** Expressions the request evaluated, in the unit of production's
   *  per-request limit of 1000. */
  evaluatedExpressions: number;
  /** The per-request limit that stopped the request, when one did. */
  resourceLimit?: RulesResourceLimit;
}

/** The structured account of why one Storage case resolved as it did. */
export type StorageExplanation = Omit<StorageCaseResult, 'case' | 'description'>;

/** Aggregate of a Storage `simulate(cases)` run. Counts partition the cases. */
export interface StorageSimulationSummary {
  passed: number;
  failed: number;
  unsupported: number;
  cases: StorageCaseResult[];
}

// ─── RTDB ────────────────────────────────────────────────────────────

/**
 * The query a Realtime Database read carries, in the members rules read as
 * `query.*`. At most one `orderBy*` member and at most one limit may be set,
 * as in the SDK.
 */
export interface RtdbCaseQuery {
  orderByChild?: string;
  orderByKey?: true;
  orderByValue?: true;
  equalTo?: string | number | boolean | null;
  startAt?: string | number | boolean | null;
  endAt?: string | number | boolean | null;
  limitToFirst?: number;
  limitToLast?: number;
}

/** A JSON tree value stored at the root of an RTDB instance. */
export type RtdbTreeData = Record<string, unknown> | unknown[] | string | number | boolean | null;

/** A case's data as one tree per database instance, keyed by instance name. */
export type RtdbInstancesData = {
  instances: Record<string, RtdbTreeData>;
};

/**
 * One Realtime Database rules case. `expectation` is required so a `simulate`
 * run can partition cases into passed/failed the same way Firestore does —
 * the RTDB simulator otherwise returns only a raw allow/deny with no notion
 * of an expectation.
 */
export interface RtdbCase {
  /** Human-readable description of what this case verifies. */
  description?: string;
  /** Expected outcome. */
  expectation: 'ALLOW' | 'DENY';
  /**
   * RTDB rule kind under test. `update` is a multi-path `update()`: every
   * path in `newData` is written together and each is judged against the
   * tree the whole update produces.
   */
  operation: 'read' | 'write' | 'validate' | 'update';
  /** Absolute, root-relative tree path, e.g. `"/users/alice"`. A path the
   *  SDK refuses, one holding `.`, `#`, `$`, `[` or `]`, is UNSUPPORTED. */
  path: string;
  /** Auth context; a bare uid string, a full identity or auth override, or `null`. */
  auth?:
    | string
    | { uid: string; tenant?: string; token?: Record<string, unknown> }
    | ({ uid: string; tenant?: string; token?: Record<string, unknown> } & Record<string, unknown>)
    | null;
  /**
   * The database instance the request goes to, by name, such as
   * `"demo-app-shard-1"`. Omit it for the default instance. A rule's `root`
   * and `data` read only this instance's tree.
   */
  instance?: string;
  /**
   * Existing data the rules read: the instance's tree, or one tree per
   * instance as `{ instances: { "<name>": tree } }`. The per-instance form
   * applies when the case names an `instance` or the ruleset holds rules per
   * instance (`rtdbRules.fromFirebaseJson`); otherwise an object whose one
   * key is `instances` is a tree with an `/instances` child, as before.
   */
  data?: RtdbTreeData | RtdbInstancesData;
  /**
   * Proposed write value (`newData`), for write/validate cases. Any JSON
   * value: a scalar such as `5` or `true` is a scalar write. For an `update`
   * case it is the patch, an object keyed by paths relative to `path`, such
   * as `{ "rooms/r1/title": "x", "rooms/r2/title": "y" }`. Its keys are
   * checked as the SDK checks `update()` keys: an invalid key, or a key that
   * is an ancestor or duplicate of another, makes the case UNSUPPORTED.
   */
  newData?: unknown;
  /**
   * For a `'write'` or `'validate'` case, the full set of paths written
   * together in one atomic multi-path `update()`, so `path`'s rules evaluate
   * against the shared post-write tree projection. It lists `path`, with
   * `newData` as its value when the case gives `newData`, and no path in it
   * is an ancestor or duplicate of another; a case that breaks either is
   * UNSUPPORTED.
   */
  updates?: Array<{ path: string; value: unknown }>;
  /**
   * The query a `read` case carries, so `query.*` rule expressions evaluate.
   * Omit it to simulate a plain read of `path`.
   */
  query?: RtdbCaseQuery;
  /**
   * The instant `now` reports in this case, in epoch milliseconds. A caller
   * hosting a sandbox passes its sandbox clock so a `now`-gated rule moves
   * with the sandbox rather than the wall clock. Omit to evaluate at the
   * real current instant.
   */
  now?: number;
}

/** The outcome of running one RTDB case through `simulate`. */
export interface RtdbCaseResult {
  case: RtdbCase;
  description?: string;
  /** The database instance the case ran on: the one it named, or the
   *  default instance of a ruleset that holds rules per instance. Absent
   *  when neither applies. */
  instance?: string;
  expectation: 'ALLOW' | 'DENY';
  decision: 'ALLOW' | 'DENY' | 'UNSUPPORTED';
  passed: boolean;
  unsupported: boolean;
  /** The tree path whose rule decided the request. */
  matchedPath: string;
  /** The expression of the rule that decided, such as `auth != null`. Empty
   *  when no rule on the path decided, as for a request denied by default or
   *  one the engine could not evaluate. */
  matchedRule: string;
  /** Engine-provided reason string. */
  reason: string;
  /** Every `.read`, `.write` and `.validate` rule the engine evaluated, in
   *  evaluation order. Empty when no rule of the operation's kind exists on
   *  the path, or when the engine could not evaluate the case. */
  trace: RtdbRuleEvaluation[];
}

export interface RtdbExplanation {
  /** See {@link RtdbCaseResult.instance}. */
  instance?: string;
  decision: 'ALLOW' | 'DENY' | 'UNSUPPORTED';
  expectation: 'ALLOW' | 'DENY';
  passed: boolean;
  unsupported: boolean;
  matchedPath: string;
  matchedRule: string;
  reason: string;
  /** See {@link RtdbCaseResult.trace}. */
  trace: RtdbRuleEvaluation[];
}

export interface RtdbSimulationSummary {
  passed: number;
  failed: number;
  unsupported: number;
  cases: RtdbCaseResult[];
  /** Which rule nodes the cases evaluated, and which they never reached. */
  coverage: RtdbCoverageSummary;
}
