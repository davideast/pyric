/**
 * The standard claims a Firebase ID token carries for an account, projected
 * from the account record. Shared by the Auth token minter, the served worker,
 * and the MCP identity surface, so every rules engine (Firestore, Realtime
 * Database, Storage) reads the same `auth.token`.
 *
 * Shape, as decoded from production ID tokens per sign-in flow:
 *
 * - `user_id` always equals the uid; `provider_id: 'anonymous'` appears on
 *   anonymous accounts only.
 * - `email` and `email_verified` appear together when the account has an
 *   email address.
 * - `name`, `picture` and `phone_number` appear only when the account has a
 *   display name, photo URL or phone number.
 * - `firebase.identities` is always present: `{}` for an account with no
 *   email, phone number or linked federated provider; otherwise keyed by
 *   identity type. The email address is listed under `email` (also for a
 *   password account), the phone number under `phone`, and each linked
 *   federated provider under its provider ID.
 *
 * When a custom claim reuses one of these names, the account value wins for
 * `user_id`, `email`, `email_verified`, `phone_number`, and `provider_id` on
 * an anonymous account; the custom value wins for `name`, `picture`, and
 * `provider_id` on any other account.
 */

/**
 * The project an ID token names when the minting side knows none, such as a
 * bare `getAuth(sandbox)`. No real project has this id, so its tokens fail an
 * admin app set up for a real project.
 */
export const SANDBOX_PROJECT_ID = 'pyric-sandbox';

/** Production's `iss` and `aud` for a project's ID tokens (capture `auth-request-auth-per-sign-in`). */
export function idTokenAudience(projectId: string): { iss: string; aud: string } {
  return { iss: `https://securetoken.google.com/${projectId}`, aud: projectId };
}

/**
 * The value rules read on `auth.token` for a signed-in session: the minted ID
 * token's full claim set, with the JWT registered claims (`sub`, `aud`,
 * `iss`, `iat`, `exp`, `auth_time`) at the values the minter put in the
 * token. Firebase's docs name `sub` in the rules token
 * (firebase.google.com/docs/rules/rules-and-auth), and RTDB capture r42 reads
 * all six in deployed rules. `auth_time` stays at the last sign-in across
 * refreshes, so a recent-login rule expires as it does in production.
 */
export function rulesTokenFromIdToken(claims: Record<string, unknown>): Record<string, unknown> {
  return { ...claims };
}

/** The account fields the projection reads. */
export interface TokenClaimAccount {
  uid: string;
  email: string | null;
  emailVerified: boolean;
  displayName: string | null;
  photoUrl: string | null;
  phoneNumber: string | null;
  isAnonymous: boolean;
  /** Provider IDs linked to the account (`password`, `phone`, `google.com`, ...). */
  providerIds: readonly string[];
}

/** An Auth account record, stored or listed: the fields the projection reads. */
export interface TokenClaimRecord {
  uid: string;
  email: string | null;
  emailVerified: boolean;
  displayName: string | null;
  photoUrl: string | null;
  phoneNumber: string | null;
  isAnonymous: boolean;
  providerUserInfo: ReadonlyArray<{ providerId: string }>;
}

export function tokenClaimAccount(record: TokenClaimRecord): TokenClaimAccount {
  return {
    uid: record.uid,
    email: record.email,
    emailVerified: record.emailVerified,
    displayName: record.displayName,
    photoUrl: record.photoUrl,
    phoneNumber: record.phoneNumber,
    isAnonymous: record.isAnonymous,
    providerIds: record.providerUserInfo.map((p) => p.providerId),
  };
}

/** Provider IDs whose identity is listed under another key: a password
 *  account's identity is its email address, a phone account's its number. */
const NON_FEDERATED_PROVIDERS = new Set(['password', 'phone', 'anonymous']);

/**
 * The claim set an ID token carries, without the JWT registered claims: the
 * account's `name` and `picture`, custom claims over them, the account's
 * other standard claims over those, then the reserved `firebase` namespace
 * with the identities map and the session's sign-in provider. A `null`
 * account (an identity with no record) yields the custom claims, `user_id`,
 * and a `firebase` namespace with empty identities.
 */
export function accountTokenClaims(
  uid: string,
  account: TokenClaimAccount | null,
  customClaims: Record<string, unknown>,
  signInProvider: string | null,
): Record<string, unknown> {
  const customOverrides: Record<string, unknown> = {};
  const accountWins: Record<string, unknown> = { user_id: uid };
  const identities: Record<string, string[]> = {};
  if (account !== null) {
    if (account.displayName !== null) customOverrides.name = account.displayName;
    if (account.photoUrl !== null) customOverrides.picture = account.photoUrl;
    if (account.isAnonymous) accountWins.provider_id = 'anonymous';
    if (account.email !== null) {
      accountWins.email = account.email;
      accountWins.email_verified = account.emailVerified;
      identities.email = [account.email];
    }
    if (account.phoneNumber !== null) {
      accountWins.phone_number = account.phoneNumber;
      identities.phone = [account.phoneNumber];
    }
    // The sandbox records no provider-side account ID for a federated link,
    // so the uid stands in as the single listed identity.
    for (const providerId of account.providerIds) {
      if (NON_FEDERATED_PROVIDERS.has(providerId)) continue;
      identities[providerId] = [account.uid];
    }
  }
  return {
    ...customOverrides,
    ...customClaims,
    ...accountWins,
    firebase: { identities, sign_in_provider: signInProvider },
  };
}

function asPlainRecord(value: unknown): Record<string, unknown> | undefined {
  if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
    return value as Record<string, unknown>;
  }
  return undefined;
}

/**
 * Complete a token claim set with the standard Firebase ID-token claims
 * (`sub`, `aud`, `iss`, `auth_time`, `iat`, `exp`, `user_id`, and
 * `firebase.identities`) that production rules read on `auth.token`,
 * preserving any caller-supplied or account-projected claims. `iss` and
 * `aud` name `projectId` as production's do; a caller that knows no project
 * gets `SANDBOX_PROJECT_ID`.
 */
export function withIdTokenClaims(
  uid: string,
  tokenClaims: Record<string, unknown>,
  nowMs: number = Date.now(),
  projectId: string = SANDBOX_PROJECT_ID,
): Record<string, unknown> {
  const issuedAtSec = Math.floor(nowMs / 1000);
  const base = accountTokenClaims(uid, null, tokenClaims, null);
  const existingFirebase = asPlainRecord(tokenClaims.firebase) ?? {};
  const baseFirebase = base.firebase as { identities: Record<string, string[]>; sign_in_provider: string | null };
  const identities = asPlainRecord(existingFirebase.identities) ?? baseFirebase.identities;
  const firebase: Record<string, unknown> = {
    ...existingFirebase,
    identities,
  };
  return {
    sub: uid,
    ...idTokenAudience(projectId),
    auth_time: issuedAtSec,
    iat: issuedAtSec,
    exp: issuedAtSec + 3600,
    ...base,
    ...tokenClaims,
    user_id: tokenClaims.user_id ?? base.user_id,
    firebase,
  };
}
